//
//  MyGymsCell.swift
//  BodGenius
//
//  Created by Zach Cervi on 1/23/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class MyGymsCell: UITableViewCell {

    @IBOutlet weak var gymName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func configureCell(text: String){
        gymName.text = text
    }
}
