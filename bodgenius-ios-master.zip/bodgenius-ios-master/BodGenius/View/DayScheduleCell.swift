//
//  DayScheduleCell.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 9/27/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class DayScheduleCell: UICollectionViewCell {
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var focusLabel: UILabel!

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.layer.cornerRadius = 10
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.borderWidth = 5.0
        self.dateLabel?.text = ""
        self.focusLabel?.text = ""
    }
}
