//
//  RoundedButton.swift
//  BodGenius
//
//  Created by Zach Cervi on 11/18/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

var originalSize: CGRect?

class RoundedButton: UIButton {

    override func awakeFromNib() {
        setupView()
    }
    
    func setupView() {
        originalSize = self.frame
        self.layer.cornerRadius = 7.0
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0)
        self.layer.borderWidth = 2.0
    }
}
