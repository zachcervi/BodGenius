//
//  ExerciseIconCollectionViewCell.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/21/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class EquipmentIconCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var equipmentName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       setupView()
    }
    
    func setupView(){
        self.layer.backgroundColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
    }
    
    func setIcon(index: Int) {
        let image = UIImage(named: ExerciseEquipment.EXERCISE_EQUIPMENT_URLS[index])
     
        icon.image = image
        equipmentName.text = ExerciseEquipment.EXERCISE_EQUIPMENT_URLS_FORMATTED[index]
//        let imageView = UIImageView(image: image)
//        imageView.contentMode = UIViewContentMode.scaleAspectFit
//        self.contentView.addSubview(imageView)
    }
    
    func toggleSelected (){
        if (isSelected){
            self.layer.backgroundColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
            self.equipmentName.isHidden = false
        }else{
            self.layer.backgroundColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
               self.equipmentName.isHidden = true
        }
    }
}
