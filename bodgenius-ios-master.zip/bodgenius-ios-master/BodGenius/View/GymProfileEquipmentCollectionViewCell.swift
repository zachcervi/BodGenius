//
//  GymProfileEquipmentCollectionViewCell.swift
//  BodGenius
//
//  Created by Zach Cervi on 1/22/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class GymProfileEquipmentCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var equipmentName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupView()
    }
    
    func setupView(){
        self.layer.backgroundColor = #colorLiteral(red: 0.4784313725, green: 0.6823529412, blue: 0.8196078431, alpha: 1)
    }
    
    func setIcon(index: Int) {
        let image = UIImage(named: ExerciseEquipment.EXERCISE_EQUIPMENT_URLS[index])
        
        icon.image = image
        equipmentName.text = ExerciseEquipment.EXERCISE_EQUIPMENT_URLS_FORMATTED[index]
        //        let imageView = UIImageView(image: image)
        //        imageView.contentMode = UIViewContentMode.scaleAspectFit
        //        self.contentView.addSubview(imageView)
        
    }
    
    func toggleSelected (){
        if (isSelected){
            self.layer.backgroundColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
            self.equipmentName.isHidden = false
        }else{
            self.layer.backgroundColor = #colorLiteral(red: 0.4784313725, green: 0.6823529412, blue: 0.8196078431, alpha: 1)
            self.equipmentName.isHidden = true
        }
    }
}
