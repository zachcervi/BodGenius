//
//  PlaceHolderText.swift
//  BodGenius
//
//  Created by Zach Cervi on 11/18/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class PlaceHolderText: UITextField {
    override func awakeFromNib() {
        setupView()
    }
    
    func setupView(){
        
    }
}
