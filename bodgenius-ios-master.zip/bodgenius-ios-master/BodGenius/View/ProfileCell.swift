//
//  ProfileCell.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/7/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class ProfileCell: UITableViewCell {

    @IBOutlet weak var profileLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
   
    }

    func configureCell(text: String){
        profileLabel.text = text
        
    }

}
