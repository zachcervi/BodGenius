//
//  WorkoutCell.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/8/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class WorkoutCell: UITableViewCell {
    @IBOutlet weak var setRepsLabel: UILabel!
    @IBOutlet weak var workoutLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    func configureCell(text: String){
        workoutLabel.text = text
        setRepsLabel.text = "4 Sets / 10 Reps Each"
    }

}
