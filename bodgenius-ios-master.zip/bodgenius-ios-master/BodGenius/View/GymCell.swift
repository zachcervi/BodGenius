//
//  GymCell.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/16/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class GymCell: UITableViewCell {

    @IBOutlet weak var gymLbl: UILabel!
    @IBOutlet weak var addGymButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    

}
