//
//  RoutineScheduleCell.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 12/16/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

var ACTIVE_COLOR = UIColor.white.cgColor
var INACTIVE_COLOR = UIColor.black.cgColor

var ACTIVE_WIDTH: CGFloat = 7.0
var INACTIVE_WIDTH: CGFloat = 5.0

class RoutineScheduleCell: UICollectionViewCell {

    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var focusLabel: UILabel!
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.layer.cornerRadius = 10
        self.layer.borderWidth = INACTIVE_WIDTH
        self.layer.borderColor = INACTIVE_COLOR
        self.dateLabel?.text = ""
        self.focusLabel?.isHidden = true
    }
    
    func setActive(active: Bool) {
        self.layer.borderColor = active ? ACTIVE_COLOR : INACTIVE_COLOR
        self.layer.borderWidth = active ? ACTIVE_WIDTH : INACTIVE_WIDTH
    }
    
    func setDateText(text: String) {
        self.dateLabel.text = text
    }
    
    func setFocusText(text: String?) {
        if(text != nil) {
            self.focusLabel.text = text!
            self.focusLabel.isHidden = false
        } else {
            self.focusLabel.isHidden = true
        }
    }
}
