//
//  LandingWorkoutCell.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 10/1/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class LandingWorkoutCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
}
