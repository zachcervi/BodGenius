//
//  EditGoalViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 9/26/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit
import Foundation

class EditGoalViewController: BGViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    var parentVc: LandingViewController!
    
    @IBOutlet weak var closeIcon: UIImageView!
    @IBOutlet weak var primaryGoal: UIPickerView!
    @IBOutlet weak var secondaryGoal: UIPickerView!
    var initialGoal = Utils.getPrimaryGoalOrNull()
    var initialSecondaryGoal = Utils.getSecondaryGoalOrNull()
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveGoal(_ sender: Any) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let primaryGoalIndex = primaryGoal.selectedRow(inComponent: 0)
        let primaryGoalString = Goals.primaryGoals[primaryGoalIndex]
        
        var goalString = primaryGoalString
        
        Utils.setPrimaryUserGoal(goal: primaryGoalString)
        var secondaryGoalString: String? = nil
        if let secondaryGoalSet = Goals.getSecondaryGoals(primaryGoal: primaryGoalString) {
            let secondaryIndex = secondaryGoal.selectedRow(inComponent: 0)
            secondaryGoalString = secondaryGoalSet[secondaryIndex]
        }
        HttpClient.persistGoal(primary: goalString, secondary: secondaryGoalString, cb: parentVc!.handleSetGoal)
        self.dismiss(animated: true, completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == primaryGoal {
            return Goals.primaryGoals.count
        } else {
            let prim = primaryGoal.selectedRow(inComponent: 0)
            let goal = Goals.primaryGoals[prim]
            if let secondaryGoals = Goals.getSecondaryGoals(primaryGoal: goal) {
                return secondaryGoals.count
            }
            return 0
        }
    }
    
   
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == primaryGoal {
            let primaryGoalString = Goals.primaryGoals[row]
            if Goals.getSecondaryGoals(primaryGoal: primaryGoalString) != nil {
                secondaryGoal.isHidden = false
            } else {
                secondaryGoal.isHidden = true
            }
        }
        
        primaryGoal.reloadComponent(0)
        secondaryGoal.reloadComponent(0)
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == primaryGoal {
            return Goals.primaryGoals[row]
        } else {
            let prim = primaryGoal.selectedRow(inComponent: 0)
            let goal = Goals.primaryGoals[prim]
            if let secondaryGoals = Goals.getSecondaryGoals(primaryGoal: goal) {
                return secondaryGoals[row]
            }
            return "UNAVAILABLE"
        }
        
    }
    
    func setupDelegates() {
        self.secondaryGoal.isHidden = true
        self.primaryGoal.delegate = self
        self.primaryGoal.dataSource = self
        self.secondaryGoal.delegate = self
        self.secondaryGoal.dataSource = self
    }
    
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        closeIcon.isUserInteractionEnabled = true
        closeIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func setPickersToSelection() {
        if(Utils.getPrimaryGoalOrNull() != nil) {
            let primG = Utils.getPrimaryGoalOrNull()!
            
            if(Goals.primaryGoals.firstIndex(of: primG) != nil) {
                let index = Goals.primaryGoals.firstIndex(of: primG)!
                self.primaryGoal.selectRow(index, inComponent: 0, animated: true)
                
                if let secGoals = Goals.getSecondaryGoals(primaryGoal: primG) {
                    if let secG = Utils.getSecondaryGoalOrNull() {
                        if let n = secGoals.firstIndex(of: secG) {
                            self.secondaryGoal.isHidden = false
                            self.secondaryGoal.selectRow(n, inComponent: 0, animated: true)
                        }
                    }
                    
                }
            }
            
        }
    }
    
    override func viewDidLoad() {
        
        self.initialGoal = Utils.getPrimaryGoalOrNull()
        self.initialSecondaryGoal = Utils.getSecondaryGoalOrNull()
        self.setupDelegates()
        self.setupGestureRecognizers()
        self.setPickersToSelection()
    }
}
