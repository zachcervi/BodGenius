//
//  BGViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 11/9/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class BGViewController: UIViewController {
    func showAlert(title: String, message: String, callback: @escaping (UIAlertAction) -> Void) {
        let alertVc = Utils.getDismissModalWithMessage(title: title, message: message, cb: callback)
        self.present(alertVc, animated: true, completion: nil)
    }
}
