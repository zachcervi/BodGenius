//
//  WorkoutViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 9/4/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit
import Alamofire
import AVKit

class AVPlayerView: UIView {
    override class var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
}

class WorkoutViewController: BGViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var subtitle: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var imageView: AVPlayerView!
    @IBOutlet weak var navBar: UINavigationBar!
    
    var imageLowered = false
    var detailsSelectionIndex = -1
    var itemsPerRow: CGFloat = 4
    var avPlayer: AVPlayer!
    var observer: NSObjectProtocol!
    var workout: Workout!
    
    var setUpdateArray = [Int]()
    
    override func viewDidAppear(_ animated: Bool) {
        let url = Bundle.main.path(forResource: "lunge", ofType: "mov")
        
        let fileUrl = URL.init(fileURLWithPath: url!)
        self.avPlayer = AVPlayer(url: fileUrl)
        self.avPlayer.actionAtItemEnd = .none
        let castedLayer = self.imageView.layer as! AVPlayerLayer
        castedLayer.player = avPlayer
        //AVAudioSession.sharedInstance().setActive(true)
        self.avPlayer.isMuted = true
        self.avPlayer.play()
        self.observer = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: self.avPlayer.currentItem, queue: .main, using: { _ in
            self.avPlayer.seek(to: kCMTimeZero)
            self.avPlayer.play()
        })
        
        if(WorkoutClient.currentWorkoutIsForToday()) {
            self.workout = WorkoutClient.getCurrentWorkout()!
            if(WorkoutClient.getSetUpdateArray() != nil) {
                self.setUpdateArray = WorkoutClient.getSetUpdateArray()!
            } else {
                self.setUpdateArray = [Int]()
                for (_, _) in self.workout.exercises.enumerated() {
                    self.setUpdateArray.append(0)
                }
            }
            self.setDateString()
            self.tableView.reloadData()
        }
     }
    
    func requestWorkout(act: UIAlertAction?) {
        let url = Urls.getCurrentWorkoutUrl(userId: Utils.getUserId()!)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: nil,encoding: JSONEncoding.default, headers: nil).responseData {
            response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            switch response.response?.statusCode {
            case 200:
                let decoder = JSONDecoder()
                let todo: Result<Workout> = decoder.decodeResponse(from: response)
                if(todo.isSuccess) {
                    self.workout = todo.value!
                    self.setUpdateArray = [Int]()
                    for (_, _) in self.workout.exercises.enumerated() {
                        self.setUpdateArray.append(0)
                    }
                    WorkoutClient.setCurrentWorkout(workout: self.workout)
                    self.setDateString()
                    self.tableView.reloadData()
                } else {
                    let title = "Could not parse workout"
                    let message = "Please contact a BodGenius engineer for help."
                    self.showAlert(title: title, message: message, callback: {_ in })
                }
                break
            default:
                let message = "Please contact a BodGenius employee for help."
                let title = "Fetching Workout Failed: " + String(describing: response.response?.statusCode)
                self.showAlert(title: message, message: title, callback: {_ in })
                break
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navBar.topItem?.title = "Today's Workout"
        self.setupGestureRecognizers()
        self.setDateString()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.subtitle.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(WorkoutViewController.workoutLabelTapped(sender:)))
        self.subtitle.addGestureRecognizer(tap)
        
    }
    
    @objc func workoutLabelTapped(sender:UITapGestureRecognizer) {
        if(WorkoutClient.currentWorkoutIsForToday()) {
            return
        }
        if(GymClient.getCurrentUserGym() != nil) {
            self.requestWorkout(act: nil)
        } else {
            let title = "No Gym Selected"
            let message = "Selecting a gym allows us to ensure that your workouts only use equipment you have access to. You can select what gym you're working out on the home page. Do you want to continue without a gym?"
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (_) in
                self.requestWorkout(act: nil)
            }))
            
            self.present(alert, animated: true, completion: {})
        }
        
    }
    
    func toggleImage() {
        var offset = self.imageView.frame.height + 50
        if self.imageLowered {
            offset = offset * -1
        }
        subtitle.isHidden = !subtitle.isHidden
        let newFrame = self.imageView.frame.offsetBy(dx: 0, dy: offset)
        let newTableFrame = self.tableView.frame.offsetBy(dx: 0, dy: offset)
        UIView.animate(withDuration: 0.25, animations: {
            self.imageLowered = !self.imageLowered
            self.imageView.frame = newFrame
            self.tableView.frame = newTableFrame
        })
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //self.toggleImage()
        self.detailsSelectionIndex = indexPath.row
        self.performSegue(withIdentifier: "showDetails", sender: self)
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        //self.toggleImage()
    }
    
    //Table View
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if WorkoutClient.currentWorkoutIsForToday() {
            return WorkoutClient.getCurrentWorkout()!.exercises.count
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "exercise") as? WorkoutCell else {return UITableViewCell()}
        let workout = WorkoutClient.getCurrentWorkout()!
        cell.configureCell(text: workout.exercises[indexPath.row].name)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(WorkoutClient.currentWorkoutIsForToday()) {
            return CGFloat(self.tableView.frame.height / CGFloat(WorkoutClient.getCurrentWorkout()!.exercises.count))
        } else {
            return 0
        }
    }


    func setDateString() {
        if WorkoutClient.currentWorkoutIsForToday() {
            self.subtitle.text = Date.getTitleStringForWorkout(workout: WorkoutClient.getCurrentWorkout()!)
        } else {
            if(WorkoutClient.isWorkoutDayForUser()) {
                self.subtitle.text = "Tap For Today's Workout"
            } else {
                self.subtitle.text = "Tap For Today's Recovery Routine"
            }
            
        }
    }
    
    //Swipes
//    func contextualToggleEditAction(forRowAtIndexPath indexPath: IndexPath)->UIContextualAction{
//        let action = UIContextualAction(style: .normal, title: "Edit") { (contextAction: UIContextualAction, sourceView: UIView, completionHandler:(Bool) -> Void) in
//            let alert = UIAlertController(title: "Change Exercise", message: "What kind of change should we make?", preferredStyle: UIAlertControllerStyle.alert)
//
//            alert.addAction(UIAlertAction(title: "Same exercise, different equipment.", style: .default, handler: { action in
//
//            }))
//
//            alert.addAction(UIAlertAction(title: "Easier version of the exercise", style: .default, handler: { action in
//
//            }))
//
//            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
//
//            }))
//
//            self.present(alert, animated: true, completion: nil)
//        }
//        action.backgroundColor = #colorLiteral(red: 0.431372549, green: 0.9254901961, blue: 0.9254901961, alpha: 1)
//        return action
//    }
//
//    func contextualDetailsAction(forRowAtIndexPath indexPath: IndexPath) -> UIContextualAction {
//        let action = UIContextualAction(style: .normal, title: "Details") { (contextAction: UIContextualAction, sourceView: UIView, completionHandler:(Bool) -> Void) in
//            self.detailsSelectionIndex = indexPath.row
//            self.performSegue(withIdentifier: "showDetails", sender: self)
//        }
//        action.backgroundColor = #colorLiteral(red: 0.1843137255, green: 0.3568627451, blue: 0.9058823529, alpha: 1)
//        return action
//    }
//
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "showDetails") {
            let destinationVC = segue.destination as! ExerciseDetailsViewController 
            destinationVC.parentVc = self
            destinationVC.autoscrollIndex = self.setUpdateArray[self.detailsSelectionIndex]
            destinationVC.index = self.detailsSelectionIndex
            destinationVC.exerciseObj = self.workout.exercises[self.detailsSelectionIndex]
            if(self.workout.metadata != nil) {
                if((self.workout.metadata?.count)! > self.detailsSelectionIndex) {
                    destinationVC.metadata = self.workout.metadata![self.detailsSelectionIndex]
                }
            }
        }
    }
    
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imageView.isUserInteractionEnabled = true
        imageView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        self.avPlayer.pause()
        self.avPlayer.seek(to: kCMTimeZero)
        NotificationCenter.default.removeObserver(self.observer)
    }
    
    func modifyWorkout(exerciseIndex: Int, exercise: Exercise, lastSet: Int) {
        workout.exercises[exerciseIndex] = exercise
        setUpdateArray[exerciseIndex] = lastSet + 1
        WorkoutClient.setSetUpdateArray(array: setUpdateArray)
        WorkoutClient.setCurrentWorkout(workout: workout)
        let userId = Utils.getUserId()
        let workoutId = workout!.id
        let url = Urls.getWorkoutUrl(userId: userId!, workoutId: workoutId)
        do {
            let decoded = try JSONEncoder().encode(self.workout)
            
            let encodedString = String(data: decoded, encoding: .utf8)
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            Alamofire.request(url, method: .post, parameters: ["workout": encodedString, "clientId": CLIENT_ID],encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                
                switch response.response?.statusCode {
                case 200:
                    let message = "Workout Save Successful"
                    let title = "This is just a debug message and will be removed in production."
                    self.showAlert(title: message, message: title, callback: {_ in })
                    break
                default:
                    let message = "Please contact a BodGenius employee for help."
                    let title = "Modifying Workout Failed"
                    self.showAlert(title: message, message: title, callback: {_ in })
                    break
                }
            }
        } catch {
            let message = "Please contact a BodGenius employee for help."
            let title = "Modifying Workout Failed"
            self.showAlert(title: message, message: title, callback: {_ in })
        }
        
        
    }
}


//Delegates
extension WorkoutViewController {
//    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        let editAction = self.contextualToggleEditAction(forRowAtIndexPath: indexPath)
//        let detailsAction = self.contextualDetailsAction(forRowAtIndexPath: indexPath)
//        let allActions = [detailsAction]
//        let swipeConfig = UISwipeActionsConfiguration(actions: allActions)//[detailsAction, editAction])
//        return swipeConfig
//    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .none
    }

}

extension Date {
    static func getTitleStringForWorkout(workout: Workout) -> String {
        if(workout.getHumanReadableType() != nil) {
            return workout.getHumanReadableType()! + ": " + Date().getShortDateString()
        }
        return Date().getShortDateString()
    }

    func getShortDateString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        return formatter.string(from: self)
    }
    
    static func getShortDateStringFromWorkout(wo: Workout) -> String {
        if(wo.date == "") {
            return Date().getShortDateString()
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        let date = formatter.date(from: wo.date)
        return date!.getShortDateString()
    }
}



    



