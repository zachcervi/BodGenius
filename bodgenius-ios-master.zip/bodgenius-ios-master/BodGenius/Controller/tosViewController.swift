//
//  tosViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 12/22/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class tosViewController: UIViewController {
    var parentSignupController: SignupViewController?
    var parentProfileController: ProfileTableViewController?
    
    @IBOutlet weak var agreeButton: UIButton!
    @IBOutlet weak var declineButton: UIButton!
    @IBOutlet weak var tosTextView: UITextView!
    

    @IBAction func closeIconPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: {})
    }
    
    @IBAction func agreeButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            if let vc = self.parentSignupController {
                vc.setTOSAgreement(hasAgreed: true)
            }
        })
    }
    
    override func viewDidLoad() {
        self.agreeButton.isEnabled = true
        var spacer = "\n\n"
        self.tosTextView.text = TOS_TEXT_INTRO + spacer + TOS_TEXT_GOALS + spacer + TOS_TEXT_WHAT_TO_DO + spacer + TOS_TEXT_DISCLAIMER_1 + spacer + TOS_TEXT_DISCLAIMER_2
    }
}
