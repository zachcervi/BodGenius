//
//  ProgressViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 1/13/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit


class ProgressViewController: BGViewController, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(tableView == suggestionTableView) {
            var count = 0
            for(_, suggestion) in suggestions.enumerated() {
                if(suggestion != "") {
                    count = count + 1
                }
            }
            return count
        } else {
            return progressData.count
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(tableView == suggestionTableView) {
            let name = tableView.visibleCells[indexPath.row].textLabel?.text
            if(name != nil) {
                if(Utils.getIdForExerciseName(name: name!) != nil) {
                    self.view.endEditing(true)
                    self.exerciseNameLabel.text = name
                    let id = Utils.getIdForExerciseName(name: name!)
                    HttpClient.getExerciseProgress(exerciseId: Int(id!)!, cb: self.handleGetProgress)
                }
            } else {
                print("Error")
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(tableView == suggestionTableView) {
            let cell = self.suggestionTableView.dequeueReusableCell(withIdentifier: PROGRESS_SUGGESTION_CELL_IDENTIFIER, for: indexPath)
            cell.textLabel?.text = self.suggestions[indexPath.row]
            cell.textLabel?.textAlignment = .center
            return cell
        } else {
            let cell = self.tableView.dequeueReusableCell(withIdentifier: EXERCISE_PROGRESS_CELL_IDENTIFIER, for: indexPath)
            cell.textLabel?.textAlignment = .center
            cell.textLabel?.text = progressData[indexPath.row]
            return cell
        }
        
    }
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var closeIcon: UIImageView!
    var spinner: UIActivityIndicatorView = UIActivityIndicatorView()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var exerciseNameLabel: UILabel!
    @IBOutlet weak var suggestionTableView: UITableView!
    
    var suggestions = ["", "", ""]
    var progressData = [String]()
    var scores: [CGFloat] = [100, 100, 100]
    var exerciseMap: [String: String]?
    
    override func viewDidLoad() {
        self.suggestionTableView.isHidden = true
        self.searchBar.delegate = self
        self.suggestionTableView.delegate = self
        self.suggestionTableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.setupGestureRecognizers()
        self.hideExerciseUX()
        self.searchBar.keyboardAppearance = .dark
        if(Utils.getStoredExerciseNames() == nil) {
            HttpClient.getAllExercises(cb: Utils.storeExerciseNameAndIds(ids:names:))
        }
    }
    
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        closeIcon.isUserInteractionEnabled = true
        closeIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: {})
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        self.suggestionTableView.isHidden = true

        print("end editing")
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.suggestionTableView.isHidden = true
        print("clicked clicked")
        //self.showSpinner()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.suggestionTableView.isHidden = true
        //self.hideSpinner()
    }
    

    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //do nothing
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.suggestionTableView.isHidden = false
        let names = Utils.getStoredExerciseNames()
        scores = [1000, 1000, 1000]
        suggestions = ["", "", ""]
        if(names != nil) {
            if(self.searchBar.text?.count ?? 0 > 4) {
                let text = self.searchBar.text!
                for(index, _) in names!.enumerated() {
                    let name = names![index]
                    let score: CGFloat = CGFloat(name.levenshtein(text)) / CGFloat(max(name.count, text.count))
                    var index = 0
                    while(index < scores.count) {
                        if(scores[index] >= score) {
                            scores.insert(score, at: index)
                            suggestions.insert(name, at: index)
                            scores.remove(at: 3)
                            suggestions.remove(at: 3)
                            break
                        }
                        index = index + 1
                    }
                }
                
            } else {
                self.suggestions = ["", "", ""]
                self.suggestionTableView.isHidden = true
            }
        } else {
            self.suggestions = ["", "", ""]
            self.suggestionTableView.isHidden = true
        }
        self.suggestionTableView.reloadData()
    }
    
    func showSpinner() {
        spinner = UIActivityIndicatorView()
        spinner.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0)
        spinner.center = self.view.center
        spinner.hidesWhenStopped = true
        spinner.activityIndicatorViewStyle =
            UIActivityIndicatorViewStyle.whiteLarge
        self.view.addSubview(spinner)
        spinner.startAnimating()
    }
    
    func hideSpinner() {
        spinner.stopAnimating()
        spinner.removeFromSuperview()
    }
    
    func showExerciseUX(exerciseName: String?) {
        self.exerciseNameLabel.isHidden = false
        self.tableView.isHidden = false
        self.exerciseNameLabel.text = exerciseName
    }
    
    func hideExerciseUX() {
        self.exerciseNameLabel.isHidden = true
        self.tableView.isHidden = true
    }
    
    func handleGetProgress(s: [String]?) {
        if(s != nil) {
            self.suggestionTableView.isHidden = true
            self.showExerciseUX(exerciseName: self.exerciseNameLabel.text)
            progressData = s!
            self.tableView.reloadData()
        } else {
            self.suggestionTableView.isHidden = false
            self.hideExerciseUX()
            progressData = [String]()
            self.tableView.reloadData()
        }
    }
}

extension String {
    subscript(index: Int) -> Character {
        return self[self.index(self.startIndex, offsetBy: index)]
    }
}
    
extension String {
    public func levenshtein(_ other: String) -> Int {
        let sCount = self.count
        let oCount = other.count
        
        guard sCount != 0 else {
            return oCount
        }
        
        guard oCount != 0 else {
            return sCount
        }
        
        let line : [Int]  = Array(repeating: 0, count: oCount + 1)
        var mat : [[Int]] = Array(repeating: line, count: sCount + 1)
        
        for i in 0...sCount {
            mat[i][0] = i
        }
        
        for j in 0...oCount {
            mat[0][j] = j
        }
        
        for j in 1...oCount {
            for i in 1...sCount {
                if self[i - 1] == other[j - 1] {
                    mat[i][j] = mat[i - 1][j - 1]       // no operation
                }
                else {
                    let del = mat[i - 1][j] + 1         // deletion
                    let ins = mat[i][j - 1] + 1         // insertion
                    let sub = mat[i - 1][j - 1] + 1     // substitution
                    mat[i][j] = min(min(del, ins), sub)
                }
            }
        }
        
        return mat[sCount][oCount]
    }
}
