//
//  AccountLandingViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 11/15/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class AccountLandingViewController: UIViewController {
    @IBOutlet weak var closeIcon: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var mainText: UILabel!
    
    var titleText: String!
    var mainTextString: String!
    
    override func viewDidLoad() {
        self.titleLabel.text = titleText
        self.mainText.text = mainTextString
        self.setupGestureRecognizers()
    }
    
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        closeIcon.isUserInteractionEnabled = true
        closeIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: {})
    }
    
    
    
}
