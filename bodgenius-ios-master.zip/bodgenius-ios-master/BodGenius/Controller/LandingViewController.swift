//
//  LandingViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 9/4/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//
import Foundation
import UIKit
import Alamofire
import SwiftyJSON

class LandingViewController: BGViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDataSource, UICollectionViewDelegate {
    var gymArray = [Gym]()
    var selectedGym: Gym?
    var isLoggedIn: Bool?
    var row: Int?
    var indexPath: IndexPath?
    var routine: [String]?
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //        let title = "View Previous Workout"
        //        let message = "You currently can't edit previous workouts, but we've saved them for you to replay offline!"
        //        self.showAlert(title: title, message: message, callback: {_ in
        //            self.tabBarController?.selectedIndex = 1
        //        })
    }
    
    func handleSetGoal(statusCode: Int, primary: String, secondary: String?) {
        if(statusCode != 200) {
            let title = "Could Not Save Goal"
            let message = "Error Code: " + String(statusCode)
            self.showAlert(title: title, message: message, callback: {_ in })
        } else {
            Utils.setPrimaryUserGoal(goal: primary)
            if secondary != nil {
                Utils.setSecondaryUserGoal(goal: secondary!)
            }
            self.goalTextLabel.text = Utils.getGoalStringOrNull()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return daysOfWeek.count + 2
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let index = Date().dayNumberOfWeek()
        let indexPath = IndexPath(item: index!, section: 0)
        self.routineCollectionView.scrollToItem(at: indexPath, at: [.centeredHorizontally], animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == 0 || indexPath.row == 8 {
            let cell = self.routineCollectionView.dequeueReusableCell(withReuseIdentifier: ROUTINE_CELL_IDENTIFIER, for: indexPath) as! DayScheduleCell
            cell.dateLabel.text = ""
            cell.focusLabel.text = ""
            return cell
        }
        let cell = self.routineCollectionView.dequeueReusableCell(withReuseIdentifier: ROUTINE_CELL_IDENTIFIER, for: indexPath) as! DayScheduleCell
        cell.dateLabel.text = daysOfWeek[indexPath.row - 1]
        if(routine != nil) {
            cell.focusLabel.text = routine![indexPath.row - 1]
        } else {
            cell.focusLabel.text = "Off"
        }
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        do {
            isLoggedIn = try Utils.isUserLoggedIn()
            
        } catch {
            isLoggedIn = false
        }
        
    }
    
    @IBOutlet weak var goalTextLabel: UILabel!
    @IBOutlet weak var editGoalIcon: UIImageView!
    @IBOutlet weak var myGymsLabel: UILabel!
    @IBOutlet weak var gymLabel: UILabel!
    
    @IBAction func addGymPressed(_ sender: Any) {
        performSegue(withIdentifier: TO_CREATE_GYM, sender: nil)
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        self.performSegue(withIdentifier: EDIT_GOAL_SEGUE, sender: self)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == EDIT_GOAL_SEGUE) {
            if let vc = segue.destination as? EditGoalViewController {
                vc.parentVc = self
            }
        } else if(segue.identifier == TO_CREATE_GYM) {
            let vc = segue.destination as! CreateGymViewController
            vc.gym = selectedGym
        } else if (segue.identifier == GYM_PROFILE){
            let vc = segue.destination as! GymProfileViewController
            vc.gym = selectedGym
        } else if (segue.identifier == TO_CREATE_GYM_FROM_LANDING) {
            let vc = segue.destination as! CreateGymViewController
            vc.gym = selectedGym
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 1){
            return gymArray.count
        }else {
            return 1
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.section == 0){
            guard let cell = self.gymTableView.dequeueReusableCell(withIdentifier: "gym") as? GymCell else {return UITableViewCell()}
            return cell
        } else {
            guard let cell = self.gymTableView.dequeueReusableCell(withIdentifier: "exerciseEquipment") as? ExerciseEquipmentCell else {return UITableViewCell()}
            let gym = gymArray[indexPath.row]
            cell.configureCell(text: gym.gymName)
            
            return cell
        }
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if(indexPath.section == 0){
//            performSegue(withIdentifier: TO_CREATE_GYM_FROM_LANDING, sender: self)
//        }else {
//            self.selectedGym = gymArray[indexPath.row]
//            performSegue(withIdentifier: GYM_PROFILE, sender: self)
//        }
//
//    }
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        let cell = gymTableView.cellForRow(at: indexPath)
        if(cell?.isSelected ?? false){
            gymTableView.delegate!.tableView?(gymTableView, willDeselectRowAt: indexPath)
            gymTableView.deselectRow(at: indexPath, animated: true)
            gymTableView.delegate!.tableView?(gymTableView, didDeselectRowAt: indexPath)
            gymLabel.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            gymLabel.text = "My Gyms"
            //enableGymForWorkoutDay()
            return nil
        }
        return indexPath
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if(indexPath.section == 0){
            return false
        }else {
            return true
        }
    }
    
    func contextualToggleEditAction(forRowAtIndexPath indexPath: IndexPath)->UIContextualAction{
        let action = UIContextualAction(style: .normal, title: "Edit") { (contextAction: UIContextualAction, sourceView: UIView, completionHandler:(Bool) -> Void) in
            
            
            self.selectedGym = self.gymArray[indexPath.row]
            self.performSegue(withIdentifier: TO_CREATE_GYM_FROM_LANDING, sender: self)
            
            
        }
        action.backgroundColor = #colorLiteral(red: 1, green: 0.6610901952, blue: 0.1919756234, alpha: 1)
        return action
        
    }
    
    
    func contextualToggleDeleteAction(forRowAtIndexPath indexPath: IndexPath)->UIContextualAction{
        let action = UIContextualAction(style: .normal, title: "Delete") { (contextAction: UIContextualAction, sourceView: UIView, completionHandler:(Bool) -> Void) in
            let alert = UIAlertController(title: "Remove Gym?", message: "Are you sure you want to remove this gym?", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
                switch action.style{
                case .default:
                    self.row = indexPath.row
                    print(self.row)
                    self.indexPath = indexPath
                    print(self.indexPath)
                    let  selectedGym = self.gymArray[self.row!]
                    let uid = Utils.getUserId()
                    let gymId = selectedGym.id
                    
                    if(uid != nil && gymId != nil){
                        let url = Urls.getGymURL(userId: uid!)
                        GymClient.deleteUserGym(url: url, gymId: gymId!, cb: self.handleDeleteGym(code:message:))
                        
                    }
                    
                    print("Yes, remove gym.")
                    
                case .cancel:
                    print("cancel")
                    
                case .destructive:
                    print("destructive")
                    
                    
                }}))
            alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action) in
                switch action.style{
                case .default:
                    print("default")
                case .cancel:
                    print("cancel")
                case.destructive:
                    print("destructive")
                }
            }))
            
            self.present(alert, animated: true, completion: nil)
            
            
        }
        action.backgroundColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        return action
    }
    @IBOutlet weak var routineCollectionView: UICollectionView!
    @IBOutlet weak var debugControl: UISegmentedControl!
    @IBOutlet weak var goalTitleLabel: UILabel!
    @IBOutlet weak var gymTableView: UITableView!
    @IBOutlet weak var navBar: UINavigationBar!
    
    @IBAction func toggleDebug(_ sender: Any) {
        Utils.toggleDebugMode()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.gymTableView.frame.height / 3
    }
    
    //TODO: Move these arrays elsewhere and rename woOfWeek to something
    //more descriptive.
    var daysOfWeek = ["Sun","Mon","Tues","Wed","Thurs", "Fri", "Sat"]
    var woOfWeek = ["Full-Body", "Off", "Off", "Upper Body", "Lower Body", "Off", "Full-Body"]
    var rainbow = [UIColor.green, UIColor.red, UIColor.blue, UIColor.yellow, UIColor.orange, UIColor.purple, UIColor.black]
    
    func handleGetGoal(code: Int, goal: String?) -> Void {
        if(code != 200){
            self.showAlert(title: "Error Fetching Goal", message: "Could not fetch goal, error code " + String(code), callback: {_ in })
            return
        }
        if(goal != nil) {
            if((goal?.contains("("))! && (goal?.contains(")"))!) {
                var splitGoal = goal!.split(separator: "(")
                if splitGoal.count != 2 {
                    self.showAlert(title: "Couldnt Save Goal", message: "Could not parse the secondary goal", callback: {_ in })
                    return
                } else {
                    print(splitGoal[0])
                    var secondaryGoal = splitGoal[1]
                    secondaryGoal.removeLast()
                    print(secondaryGoal)
                }
            } else {
                Utils.setPrimaryUserGoal(goal: goal!)
            }
            self.goalTextLabel.text = goal!
        }
    }
    
//    func handleGetRoutine(code: Int, routine: Routine?) -> Void {
//        if(code != 200) {
//            //self.showAlert(title: "Error Fetching Routine", message: "Could not fetch routine. (" + String(code) + ")", callback: {_ in})
//        } else {
//            if(routine != nil) {
//                self.routine = routine
//                self.routineCollectionView.reloadData()
//            }
//        }
//    }
    
    func handleGetGym(code: Int, gyms: [Gym]?)-> Void{
        if(code != 200){
            //self.showAlert(title: "Error", message: self.getErrorMessageFromCodes(routine: getRoutineCode, gym: getGymCode), callback: {_ in})
            return
        }else {
            if(gyms != nil){
                if(gyms!.count > 0){
                    for gym in gyms! {
                        if(!gymArray.contains(where: {$0.gymName == gym.gymName})){
                            gymArray.append(gym)
                        }else {
                            continue
                        }
                    }
                    gymLabel.text = "Where are you working out today?"
                    for (_, n) in self.gymArray.enumerated() {
                        if(n.id != nil && n.id == GymClient.getCurrentUserGym()) {
                            gymLabel.text = "Working out at: \(n.gymName)"
                        }
                    }
                    Utils.cacheUserGyms(gyms: gymArray)
                    self.gymTableView.reloadData()
                } else {
                    let gym = Gym(id: NSUUID().uuidString, gymName: "BodGenius Gym", exerciseEquipment: "BodGenius Exercise Equipment")
                    gymArray = [gym]
                    self.gymTableView.reloadData()
                }
            }
        }
    }
    
    func handleDeleteGym(code: Int, message: String?)-> Void {
        if(code == 200){
            self.gymArray.remove(at: self.row!)
            self.gymTableView.deleteRows(at: [self.indexPath!], with: .fade)
            self.gymTableView.reloadData()
        }
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        if (Utils.getGoalStringOrNull() != nil) {
            self.goalTextLabel.text = Utils.getGoalStringOrNull()!
        } else {
            self.goalTextLabel.text = "No Goal Set"
            //TODO: Re-enable when goal UX is ready
            //HttpClient.getUserGoal(cb: self.handleGetGoal)
        }
        
        if (isLoggedIn == true){
            GymClient.getUserGym(cb: self.handleGetGym(code:gyms:))
        }
        else {
            print("User is not logged in.")
        }
    }
    
    func setupDelegates() {
        self.routineCollectionView.delegate = self
        self.routineCollectionView.dataSource = self
        self.gymTableView.delegate = self
        self.gymTableView.dataSource = self
        self.gymTableView.isScrollEnabled = true
    }
    
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        editGoalIcon.isUserInteractionEnabled = true
        editGoalIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func getWorkout() {}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.routine = Utils.getUserRoutine()
        self.routineCollectionView.alwaysBounceVertical = false
        self.navBar.topItem?.title = "BodGenius"
        self.setupDelegates()
        self.setupGestureRecognizers()
        self.getWorkout()
        self.enableGymForWorkoutDay()
        gymTableView.delegate = self
        gymTableView.dataSource = self
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap))
        singleTap.numberOfTapsRequired = 1
        view.addGestureRecognizer(singleTap)
        
//        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap))
//        doubleTap.numberOfTapsRequired = 2
//        view.addGestureRecognizer(doubleTap)
        gymLabel.text = "Where are you working out today?"
        for (_, n) in self.gymArray.enumerated() {
            if(n.id != nil && n.id == GymClient.getCurrentUserGym()) {
                gymLabel.text = "Working out at: \(n.gymName)"
            }
        }
    }
    
    @objc  func handleSingleTap(recognizer: UIGestureRecognizer){
        print("Single tap")
        let p = recognizer.location(in: gymTableView)
        let indexPath = gymTableView.indexPathForRow(at: p)
        
        if let _ = indexPath {
            if(indexPath?.section == 0){
                performSegue(withIdentifier: TO_CREATE_GYM_FROM_LANDING, sender: self)
            } else {
                self.selectedGym = gymArray[indexPath!.row]
                performSegue(withIdentifier: GYM_PROFILE, sender: self)
            }
        }
    }
    @objc func handleDoubleTap(recognizer: UIGestureRecognizer){
        print("Double Tap")
        let p = recognizer.location(in: gymTableView)
        let indexPath = gymTableView.indexPathForRow(at: p)
        
        if let _ = indexPath {
            gymTableView.deselectRow(at: indexPath!, animated: true)
            if(indexPath?.section == 0){
                performSegue(withIdentifier: TO_CREATE_GYM_FROM_LANDING, sender: self)
            }else {
                let gym = gymArray[indexPath!.row]
                
                if(GymClient.getCurrentUserGym() != nil) {
                    gymLabel.text = "Where are you working out today?"
                    GymClient.setCurrentUserGym(gymId: nil)
                } else {
                    GymClient.setCurrentUserGym(gymId: gym.id)
                    gymLabel.text = "Working out at: \(gym.gymName)"
                }
                gymLabel.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0)
            }
        }
        
    }
    
    func enableGymForWorkoutDay(){
        if woOfWeek[Date().dayNumberOfWeek()! - 1] != "Off" {
            myGymsLabel.text = "Where are you working out today?"
        }else{
            myGymsLabel.text = "My Gyms"
        }
        
    }
    
    func configurationTextField(textField: UITextField!) {}
}


extension Date {
    func dayNumberOfWeek() -> Int? {
        return Calendar.current.dateComponents([.weekday], from: self).weekday
    }
}
extension LandingViewController {
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let editAction = self.contextualToggleEditAction(forRowAtIndexPath: indexPath)
        let deleteAction = self.contextualToggleDeleteAction(forRowAtIndexPath: indexPath)
        let swipeConfig = UISwipeActionsConfiguration(actions: [editAction, deleteAction])
        return swipeConfig
    }
    
}
