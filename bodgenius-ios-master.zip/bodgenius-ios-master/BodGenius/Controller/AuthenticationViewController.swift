//
//  AuthenticationViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 11/9/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class AuthenticationViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var authenticateButton: UIButton!
    @IBOutlet weak var envSwitch: UISegmentedControl!
    
    @IBOutlet weak var stackView: UIStackView!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if textField == self.emailField { // Switch focus to other text field
            passwordField.becomeFirstResponder()
        }
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.emailField.delegate = self
        self.passwordField.delegate = self
        emailField.delegate = self
        passwordField.delegate = self
        
        emailField.tintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        passwordField.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        emailField.keyboardAppearance = .dark
        passwordField.keyboardAppearance = .dark
        //init toolbar
        if let value = ProcessInfo.processInfo.environment["isLocalBuild"] {
            self.envSwitch.isHidden = (value != "true")
        } else {
            self.envSwitch.isHidden = true
        }
        let server = Urls.getBaseUrl()

        let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                    kSecAttrServer as String: server,
                                    kSecMatchLimit as String: kSecMatchLimitOne,
                                    kSecReturnAttributes as String: true,
                                    kSecReturnData as String: true]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        
        guard let existingItem = item as? [String : Any],
            let passwordData = existingItem[kSecValueData as String] as? Data,
            let password = String(data: passwordData, encoding: String.Encoding.utf8),
            let account = existingItem[kSecAttrAccount as String] as? String
            else {
                print("Error fetching password")
                return
        }
        if(password != nil && account != nil) {
            self.showSpinner()
            UserClient.authenticateUser(account: account, password: password, sender: self)
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @objc func doneButtonAction() {
        self.emailField.endEditing(true)
        self.passwordField.endEditing(true)
    }
    
    @IBAction func envSwitched(_ sender: Any) {
        Utils.setUserEnv(env: self.envSwitch.selectedSegmentIndex + 1)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.envSwitch.selectedSegmentIndex = Utils.getUserEnv() - 1
        var isLoggedIn = false
        do {
            isLoggedIn = try Utils.isUserLoggedIn()
        } catch {
            isLoggedIn = false
        }
    }
    
    @IBAction func authenticate(_ sender: Any) {
        if(self.emailField.text == nil || self.emailField.text?.count == 0) {
            self.present(Utils.getDismissModalWithMessage(title: "No Username", message: "Please provide a username to authenticate with.", cb: nil), animated: true, completion: nil)
            return
        }
        if(self.passwordField.text == nil || self.passwordField.text?.count == 0) {
            self.present(Utils.getDismissModalWithMessage(title: "No Password", message: "Please provide a password to authenticate with.", cb: nil), animated: true, completion: nil)
            return
        }
        let password = self.passwordField.text!
        self.showSpinner()
        UserClient.authenticateUser(account: self.emailField.text!, password: password, sender: self)
    }
    
    func goToLanding() {
        HttpClient.getAllExercises(cb: Utils.storeExerciseNameAndIds(ids:names:))
        performSegue(withIdentifier: POST_AUTHENTICATION_SEGUE, sender: self)
    }
    
    
    var spinner: UIActivityIndicatorView?
    func showSpinner() {
        spinner = UIActivityIndicatorView()
        spinner!.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0)
        spinner!.center = self.view.center
        spinner!.hidesWhenStopped = true
        spinner!.activityIndicatorViewStyle =
            UIActivityIndicatorViewStyle.whiteLarge
        self.view.addSubview(spinner!)
        spinner!.startAnimating()
        self.emailField.isHidden = true
        self.passwordField.isHidden = true
        self.authenticateButton.isHidden = true
        self.stackView.isHidden = true
        //self.titleLabel.isHidden = true
    }
    
    func hideSpinner() {
        //self.titleLabel.isHidden = false
        self.stackView.isHidden = false
        self.emailField.isHidden = false
        self.passwordField.isHidden = false
        self.authenticateButton.isHidden = false
        if(self.spinner != nil) {
            self.spinner!.removeFromSuperview()
            self.spinner = nil
        }
    }
    
}
