//
//  ExerciseDetailsViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 10/10/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable
class ExerciseDetailsViewController: BGViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let repsIndex = self.repsPicker.selectedRow(inComponent: 0)
        let weightIndex = self.weightPicker.selectedRow(inComponent: 0)
        let set = self.setSegmentedControl.selectedSegmentIndex
        
        self.recordChange(set: set, reps: Int(getRepDataset()[repsIndex])!, weight: Int(getWeightsDataset()[weightIndex])!)
    }

    func getRepDataset() -> [String] {
        return ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    }
    
    
    @IBAction func onSetChange(_ sender: Any) {
        self.adjustUxForSet()
    }
    
    func adjustUxForSet() {
        let set = self.setSegmentedControl.selectedSegmentIndex
        self.setTitleLabel.text = "Set #" + String(set + 1)
        self.repsPicker.selectRow(exerciseObj.reps[set], inComponent: 0, animated: true)
        let weight = exerciseObj.weights[set]
        if(getWeightsDataset().contains(String(weight))) {
            let index = getWeightsDataset().firstIndex(of: String(weight))
            self.weightPicker.selectRow(index!, inComponent: 0, animated: true)
        }
    }
    
    
    func getWeightsDataset() -> [String] {
        var arr = [String]()
        var counter = 0
        let max = 250
        
        while counter <= max {
            counter = counter + 5
            arr.append(String(counter))
        }
        return arr
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(pickerView == repsPicker) {
            return getRepDataset().count
        } else {
            return getWeightsDataset().count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        if(pickerView == repsPicker) {
            let string = getRepDataset()[row]
            return NSAttributedString(string: string, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        } else {
            let string = getWeightsDataset()[row]
            return NSAttributedString(string: string, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        }
    }
    
    @IBOutlet weak var metadataLabel: UILabel!
    @IBOutlet weak var weightPicker: UIPickerView!
    @IBOutlet weak var repsPicker: UIPickerView!
    @IBOutlet weak var setSegmentedControl: UISegmentedControl!
    @IBOutlet weak var setTitleLabel: UILabel!
    @IBOutlet weak var closeIcon: UIImageView!
    @IBOutlet weak var exerciseTitle: UILabel!
    
    var parentVc: WorkoutViewController!
    var index: Int!
    var autoscrollIndex: Int!
    var metadata: String?
    var highestUpdatedSet = -1
    
    func recordChange(set: Int, reps: Int, weight: Int) {
        if (set > highestUpdatedSet) {
            highestUpdatedSet = set
        }
        exerciseObj.reps[set] = reps
        exerciseObj.weights[set] = weight
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if(highestUpdatedSet >= 0) {
            parentVc.modifyWorkout(exerciseIndex: index, exercise: exerciseObj, lastSet: highestUpdatedSet)
        }
        
    }
    
    var exerciseObj: Exercise!
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer){
        self.dismiss(animated: true, completion: nil)
    }
    
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        closeIcon.isUserInteractionEnabled = true
        closeIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    override func viewDidLoad() {
        self.setupGestureRecognizers()
        self.exerciseTitle.text = self.exerciseObj.name.capitalized
        self.repsPicker.dataSource = self
        self.repsPicker.setValue(UIColor.white, forKey: "textColor")
        self.repsPicker.delegate = self
        self.weightPicker.dataSource = self
        self.weightPicker.delegate = self
        self.weightPicker.setValue(UIColor.white, forKey: "textColor")
        while(self.autoscrollIndex >= self.setSegmentedControl.numberOfSegments) {
            self.autoscrollIndex = self.autoscrollIndex - 1
        }
        self.setSegmentedControl.selectedSegmentIndex = self.autoscrollIndex
        self.adjustUxForSet()
        if(self.metadata != nil) {
            self.metadataLabel.text = self.metadata!
        } else {
            self.metadataLabel.isHidden = true
        }

    }
    
    
}
