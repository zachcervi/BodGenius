//
//  ProfileTableViewController.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/7/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class ProfileTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var stagedTitle: String = ""
    var stagedMessage: String = ""

    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var tableView: UITableView!
    
    
    
    
    var comingFromAccountCreation: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navBar.topItem?.title = "My Profile"
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if(comingFromAccountCreation != nil) {
            self.comingFromAccountCreation = nil
            self.performSegue(withIdentifier: ROUTINE_FROM_PROFILE_SEGUE, sender: self)
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return profileArray.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "profileCell", for: indexPath) as? ProfileCell else {return UITableViewCell()}
        if(indexPath.row != 0) {
            cell.configureCell(text: profileArray[indexPath.row])
        } else {
            cell.isUserInteractionEnabled = false
            if let versionNo = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as? String {
                cell.configureCell(text: "App Version: " + versionNo)
            } else {
                cell.configureCell(text: profileArray[indexPath.row])
            }
            
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.view.frame.height / CGFloat(profileArray.count + 2)
    }
    
    func setStagedContent(key: String) {
        self.stagedTitle = key
        self.stagedMessage = accountStubMap[key]!
    }
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = self.tableView.visibleCells[indexPath.row] as! ProfileCell
       
        if (indexPath.row == 0) {
            tableView.deselectRow(at: indexPath, animated: false)
            return
        }
        switch cell.profileLabel.text! {
            case "Bod Genius":
                break
            case "My Progress":
                performSegue(withIdentifier: PROGRESS_FROM_PROFILE, sender: self)
            case "Current Injuries":
                self.setStagedContent(key: cell.profileLabel.text!)
                performSegue(withIdentifier: STUB_ACCOUNT_SEGUE, sender: self)
            case "Routine":
                performSegue(withIdentifier: ROUTINE_FROM_PROFILE_SEGUE, sender: self)
            case "My Gyms":
                performSegue(withIdentifier: TO_MY_GYMS_FROM_MY_PROFILE, sender: self)
            break
            case "Notifications":
                self.setStagedContent(key: cell.profileLabel.text!)
                performSegue(withIdentifier: STUB_ACCOUNT_SEGUE, sender: self)
            case "Payment & Billing":
                self.setStagedContent(key: cell.profileLabel.text!)
                performSegue(withIdentifier: STUB_ACCOUNT_SEGUE, sender: self)
            case "Privacy & Data":
                self.setStagedContent(key: cell.profileLabel.text!)
                performSegue(withIdentifier: STUB_ACCOUNT_SEGUE, sender: self)
            case "Logout":
                self.logout()
                break
            default:
                break
        }
    }
    
    func logout() {
        let alert = UIAlertController(title: "Log Out", message: "Would you like to sign out of the current profile?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Log Out", style: .default, handler: { action in
            let server = Urls.getBaseUrl()
            Utils.setUserId(id: nil)
            Utils.setSecondaryUserGoal(goal: nil)
            Utils.setPrimaryUserGoal(goal: nil)
            Utils.clearUser()
            let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                        kSecAttrServer as String: server]
            
            let status = SecItemDelete(query as CFDictionary)
            if status != errSecSuccess {
                print ("KeychainError")
                print(status)
            } else {
                print("Keychain Deletion Successful")
            }
            self.performSegue(withIdentifier: LOGOUT_SEGUE, sender: self)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let indexPath = self.tableView.indexPathForSelectedRow {
            self.tableView.deselectRow(at: indexPath, animated: true)
        }
        if segue.identifier == STUB_ACCOUNT_SEGUE {
            if let vc = segue.destination as? AccountLandingViewController {
                vc.mainTextString = stagedMessage
                vc.titleText = stagedTitle
            }
        }
    }
}


var accountStubMap : [String : String] = [
    "My Progress": "As this page gets built out, you'll be able to view your progress through a variety of different metrics. See how often you're working out and track your weights and reps for each exercise over time.",
    "Current Injuries": "When you wake up to some lower back pain, your fitness routine doesnt need to be thrown out the window. Come to this page when you're not feeling 100% somewhere and want your workout to accomodate for that.",
    "Routine": "Here you can set how often you want to work out as well as which days work best for you. If you're going on vacation for a week, let us know and we'll give you some nice simple maintenance workouts. If your schedule looks erratic for the next month, put yourself on an auto-balanced routine and work out whenever you can!",
    "Notifications": "This page will be where you can configure how often we send you notifications and emails.",
    "Payment & Billing": "This page will be where you can configure any payment methods and membership plans that you are on.",
    "Privacy & Data": DATA_PRIVACY_1
]
