//
//  MyGymsViewController.swift
//  BodGenius
//
//  Created by Zach Cervi on 1/23/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class MyGymsViewController: BGViewController, UITableViewDelegate, UITableViewDataSource {
    
    //Variables
    var gymArray = [Gym]()
    var selectedGym: Gym?
    var isLoggedIn: Bool?
    var row: Int?
    var indexPath: IndexPath?
    
    //Outlets
    @IBOutlet weak var myGymsLabel: UILabel!
    @IBOutlet weak var gymTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        gymTableView.delegate = self
        gymTableView.dataSource = self
        gymTableView.isScrollEnabled = true
    }
    @IBAction func closeBtnPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gymArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.gymTableView.dequeueReusableCell(withIdentifier: "gym") as? MyGymsCell else {return UITableViewCell()}
        let gym = gymArray[indexPath.row]
        cell.configureCell(text: gym.gymName)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedGym = gymArray[indexPath.row]
        performSegue(withIdentifier: TO_GYM_PROFILE_FROM_USER_PROFILE, sender: self)
    }
    override func viewWillAppear(_ animated: Bool) {
        do {
            isLoggedIn = try Utils.isUserLoggedIn()
            
        } catch {
            isLoggedIn = false
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == TO_GYM_PROFILE_FROM_USER_PROFILE){
            let vc = segue.destination as! GymProfileViewController
            vc.gym = selectedGym
        }
        else if (segue.identifier == TO_CREATE_GYM_FROM_MY_GYMS){
            let vc = segue.destination as! CreateGymViewController
            vc.gym = selectedGym
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if (isLoggedIn == true){
            print("User is logged in.")
            
            GymClient.getUserGym(cb: self.handleGetGym(code:gyms:))
            
        }
        else {
            print("User is not logged in.")
        }
    }
    
    
    //API Handlers
    func handleGetGym(code: Int, gyms: [Gym]?)-> Void{
        if(code != 200){
            self.showAlert(title: "Error Fething Gym", message: "Could not fetch gym, error code " + String(code
                ), callback: {_ in})
            return
        }else {
            if(gyms != nil){
                if(gyms!.count > 0){
                    for gym in gyms! {
                        if(!gymArray.contains(where: {$0.gymName == gym.gymName})){
                            gymArray.append(gym)
                        }else {
                            continue
                        }
                    }
                    self.gymTableView.reloadData()
                }else {
                    
                    let gym = Gym(id: NSUUID().uuidString, gymName: "BodGenius Gym", exerciseEquipment: "BodGenius Exercise Equipment")
                    gymArray.append(gym)
                    self.gymTableView.reloadData()
                }
            }
        }
    }
    
    func handleDeleteGym(code: Int, message: String?)-> Void {
        if(code == 200){
            self.gymArray.remove(at: self.row!)
            self.gymTableView.deleteRows(at: [self.indexPath!], with: .fade)
            self.gymTableView.reloadData()
        }
    }
    
    
    //Contextual Actions
    func contextualToggleEditAction(forRowAtIndexPath indexPath: IndexPath)->UIContextualAction{
        let action = UIContextualAction(style: .normal, title: "Edit") { (contextAction: UIContextualAction, sourceView: UIView, completionHandler:(Bool) -> Void) in
            self.selectedGym = self.gymArray[indexPath.row]
            self.performSegue(withIdentifier: TO_CREATE_GYM_FROM_MY_GYMS, sender: self)
            
        }
        action.backgroundColor = #colorLiteral(red: 1, green: 0.6610901952, blue: 0.1919756234, alpha: 1)
        return action
    }
        
        func contextualToggleDeleteAction(forRowAtIndexPath indexPath: IndexPath)->UIContextualAction{
            let action = UIContextualAction(style: .normal, title: "Delete") { (contextAction: UIContextualAction, sourceView: UIView, completionHandler:(Bool) -> Void) in
                let alert = UIAlertController(title: "Remove Gym?", message: "Are you sure you want to remove this gym?", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
                    switch action.style{
                    case .default:
                        self.row = indexPath.row
                        print(self.row)
                        self.indexPath = indexPath
                        print(self.indexPath)
                        let  selectedGym = self.gymArray[self.row!]
                        let uid = Utils.getUserId()
                        let gymId = selectedGym.id
                        
                        if(uid != nil && gymId != nil){
                            let url = Urls.getGymURL(userId: uid!)
                            GymClient.deleteUserGym(url: url, gymId: gymId!, cb: self.handleDeleteGym(code:message:))
                            
                        }
                        
                        print("Yes, remove gym.")
                        
                    case .cancel:
                        print("cancel")
                        
                    case .destructive:
                        print("destructive")
                        
                        
                    }}))
                alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action) in
                    switch action.style{
                    case .default:
                        print("default")
                    case .cancel:
                        print("cancel")
                    case.destructive:
                        print("destructive")
                    }
                }))
                
                self.present(alert, animated: true, completion: nil)
                
                
            }
            action.backgroundColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
            return action
        }
    
    
}
extension MyGymsViewController{
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let editAction = self.contextualToggleEditAction(forRowAtIndexPath: indexPath)
        let deleteAction = self.contextualToggleDeleteAction(forRowAtIndexPath: indexPath)
        let swipeConfig = UISwipeActionsConfiguration(actions: [editAction, deleteAction])
        return swipeConfig
    }
}
