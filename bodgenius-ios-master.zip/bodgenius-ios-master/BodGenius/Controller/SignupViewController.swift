//
//  SignupViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 12/11/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import UIKit

class SignupViewController: BGViewController, UITextFieldDelegate {
    
    @IBOutlet weak var emailInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    @IBOutlet weak var confirmPasswordInput: UITextField!
    @IBOutlet weak var createAccountButton: UIButton!
    
    var MIN_PASSWORD_LENGTH = 8
    var hasAgreedToTerms = false
    
    @IBAction func closeIconPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: {})
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == TOS_SEGUE) {
            let vc = segue.destination as! tosViewController
            vc.parentSignupController = self
        } else if (segue.identifier == LOGIN_FROM_NEW_ACCOUNT) {
            let profileIndex = 2
            let vc = segue.destination as! UITabBarController
            vc.selectedIndex = profileIndex
            if (vc.viewControllers!.count >= 3) {
                let specificVc = vc.viewControllers![profileIndex] as! ProfileTableViewController
                specificVc.comingFromAccountCreation = true
            }
        }
    }
    
    @IBAction func createAccount(_ sender: Any) {
        if (!hasAgreedToTerms) {
            performSegue(withIdentifier: TOS_SEGUE, sender: self)
            return
        }
        let allInputs: [UITextField] = [emailInput, passwordInput, confirmPasswordInput]
        for (_, input) in allInputs.enumerated() {
            if(input.text == nil || input.text == "") {
                let alert = Utils.getDismissModalWithMessage(title: "Error", message: "Not all three fields are filled.", cb: nil)
                self.present(alert, animated: true, completion: {})
                return
            }
        }
        let email = emailInput.text!
        let password = passwordInput.text!
        let confirmedPassword = confirmPasswordInput.text!
        
        if (!self.validateEmail(email: email)) {
            let alert = Utils.getDismissModalWithMessage(title: "Error", message: "Email is not valid. Please provide a valid email address.", cb: nil)
            self.present(alert, animated: true, completion: {})
            return
        }
        if (!self.validatePassword(password: password)) {
            let alert = Utils.getDismissModalWithMessage(title: "Error", message: "Password is not valid. Please provide a valid password.", cb: nil)
            self.present(alert, animated: true, completion: {})
            return
        }
        if(password != confirmedPassword) {
            let alert = Utils.getDismissModalWithMessage(title: "Error", message: "Passwords do not match.", cb: nil)
            self.present(alert, animated: true, completion: {})
            return
        }
        self.setSuccessLabelForEmail(email: email)
        UserClient.createAccount(cb: self.handleCreateAccountResponse, email: email, password: password)
    }
    
    func validateEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: email)
    }
    
    func validatePassword(password: String) -> Bool {
        return (password.count >= MIN_PASSWORD_LENGTH)
    }
    
    func handleCreateAccountResponse(userId: String?) {
        if(userId == nil) {
            let alert = Utils.getDismissModalWithMessage(title: "Error", message: "Could not create account. Please contact a BodGenius Engineer for help.", cb: nil)
            self.present(alert, animated: true, completion: {})
            return
        } else if(userId == ERR_DUPLICATE_EMAIL) {
            let alert = Utils.getDismissModalWithMessage(title: "Error: Email Taken", message: "The email you provided is already associated with a BodGenius account. Please use a different one.", cb: nil)
            self.present(alert, animated: true, completion: {})
            return
        } else {
            Utils.setUserId(id: userId)
            self.animateAwayCreateButton()
        }
    }
    
    func setTOSAgreement(hasAgreed: Bool) {
        self.hasAgreedToTerms = hasAgreed
        let titleText = hasAgreed ? "Create Account" : "View Terms Of Service"
        self.createAccountButton.setTitle(titleText, for: UIControlState.normal)
    }
    
    override func viewDidLoad() {
        self.successLabel.isHidden = true
        self.setTOSAgreement(hasAgreed: false)
        self.createAccountButton.titleLabel?.textAlignment = NSTextAlignment.center
        self.successView.isHidden = true
        self.successView.layer.cornerRadius = 2
        self.successView.layer.borderColor = UIColor.white.cgColor
        self.successView.layer.borderWidth = 1
        self.successView.isUserInteractionEnabled = false
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleSuccessViewTap(sender:)))
        self.successView.addGestureRecognizer(tap)
        
        emailInput.delegate = self
        emailInput.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        passwordInput.delegate = self
        passwordInput.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        confirmPasswordInput.delegate = self
        confirmPasswordInput.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @objc func handleSuccessViewTap(sender: UITapGestureRecognizer? = nil) {
        if (self.canGoToRoutine) {
            self.performSegue(withIdentifier: LOGIN_FROM_NEW_ACCOUNT, sender: self)
            print("Going to routine!")
        } else {
            print("Can't go to routine!")
        }
    }
    
    @IBOutlet weak var successView: UIView!
    @IBOutlet weak var successLabel: UILabel!
    
    
    func setSuccessLabelForEmail(email: String) {
        self.successLabel.text = "Account successfully created! We've sent a confirmation email to " + email + ". Make sure to open it up and go to the provided link within 48 hours to activate your account. For now, tap this text to find your routine."
    }
    
    var canGoToRoutine = false
    
    func animateAwayCreateButton() {
        UIView.animate(withDuration: 0.5, animations: {
            self.createAccountButton.layer.opacity = 0
            self.successView.isHidden = false
            self.successLabel.isHidden = false
        }, completion: { (completed) in
            self.canGoToRoutine = true
            self.successView.isUserInteractionEnabled = true
        })
    }
}
