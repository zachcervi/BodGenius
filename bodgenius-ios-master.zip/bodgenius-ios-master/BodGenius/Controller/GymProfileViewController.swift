//
//  GymProfileViewController.swift
//  BodGenius
//
//  Created by Zach Cervi on 1/22/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class GymProfileViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    //variables
    var gym: Gym?
    
    //IBOutlets
    @IBOutlet weak var equipmentCollectionView: UICollectionView!
    @IBOutlet weak var gymName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.equipmentCollectionView.delegate = self
        self.equipmentCollectionView.dataSource = self
        self.equipmentCollectionView.allowsMultipleSelection = true

        if(gym != nil){
            gymName.text = gym?.gymName
        }
    }
    
    @IBAction func closeButtonPressed(_ sender: Any) {
         dismiss(animated: true, completion: nil)
    }
    
    @IBAction func editButtonPressed(_ sender: Any) {
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat((equipmentCollectionView.frame.size.width / 3) - 20), height: CGFloat(100))
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ExerciseEquipment.EXERCISE_EQUIPMENT_URLS.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "equipmentIcon", for: indexPath) as? GymProfileEquipmentCollectionViewCell{
            cell.setIcon(index: indexPath.row)
            return cell
        }
        return EquipmentIconCollectionViewCell()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = equipmentCollectionView.cellForItem(at: indexPath) as! GymProfileEquipmentCollectionViewCell
        cell.toggleSelected()
        
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = equipmentCollectionView.cellForItem(at: indexPath) as! GymProfileEquipmentCollectionViewCell
        cell.toggleSelected()
    }
}
