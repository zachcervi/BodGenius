//
//  CreateGymViewController.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/21/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import UIKit

class CreateGymViewController: BGViewController,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITextFieldDelegate  {

    //variables
    var gym: Gym?
    
    //Outlets
    @IBOutlet weak var gymTextField: UITextField!
    @IBOutlet weak var equipmentCollectionView: UICollectionView!
    @IBOutlet weak var gymIcon: UIImageView!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    var equipmentMap: [String : Bool] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        equipmentCollectionView.delegate = self
        equipmentCollectionView.dataSource = self
        equipmentCollectionView.allowsMultipleSelection = true
        gymTextField.delegate = self
        gymTextField.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        gymTextField.keyboardAppearance = .dark
        for (_, n) in ExerciseEquipment.EXERCISE_EQUIPMENT_URLS.enumerated() {
            equipmentMap[n] = false
        }
        
        if(gym != nil){
            gymTextField.text = gym!.gymName
            let splitEquipment = gym!.exerciseEquipment.components(separatedBy: "&")
            for (_, equipment) in splitEquipment.enumerated() {
                if(equipmentMap[equipment] != nil) {
                    equipmentMap[equipment] = true
                }
            }
        }
        
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat((equipmentCollectionView.frame.size.width / 3) - 20), height: CGFloat(100))
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ExerciseEquipment.EXERCISE_EQUIPMENT_URLS.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "equipmentIcon", for: indexPath) as? EquipmentIconCollectionViewCell{
            cell.setIcon(index: indexPath.row)
            
            let equipment = ExerciseEquipment.EXERCISE_EQUIPMENT_URLS[indexPath.row]
            if(equipmentMap[equipment] ?? false) {
                self.equipmentCollectionView.selectItem(at: indexPath, animated: false, scrollPosition: .centeredHorizontally)
            }
            cell.isSelected = equipmentMap[equipment] ?? false
            cell.toggleSelected()
            return cell
        }
        return EquipmentIconCollectionViewCell()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let equipment = ExerciseEquipment.EXERCISE_EQUIPMENT_URLS[indexPath.row]
        equipmentMap[equipment] = !equipmentMap[equipment]!
        self.equipmentCollectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let equipment = ExerciseEquipment.EXERCISE_EQUIPMENT_URLS[indexPath.row]
        equipmentMap[equipment] = !equipmentMap[equipment]!
        self.equipmentCollectionView.reloadData()
    }

    func handleEditGym(code: Int, message: String?)-> Void {
        //The api is returning a 404 when updating gym with a SUCCESS message?
        if(code == 404){
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    func handleCreateGym(gymId: String?) {
        if(gymId != nil) {
            let vc = Utils.getDismissModalWithMessage(title: "Creation Successful", message: "", cb: { _ in
                self.dismiss(animated: true, completion: nil)
                })
            self.present(vc, animated: true, completion: nil)
        } else {
            let vc = Utils.getDismissModalWithMessage(title: "Creation Failed", message: "Could not create gym", cb: nil)
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    func getEquipmentString() -> String {
        var equipment = [String]()
        for (_, pair) in self.equipmentMap.enumerated() {
            if (pair.value) {
                equipment.append(pair.key)
            }
        }
        var equipmentString = "none"
        if (equipment.count > 0) {
            equipmentString = equipment.joined(separator: "&")
        }
        return equipmentString
    }
    
    @IBAction func closeButtonPressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        //AlamoFire request
        // gym id is not nil so it will be an update
        if(gym != nil){
            if(gymTextField.text != nil || gymTextField.text != ""){
                gym?.gymName = gymTextField.text!
                //update the exercise equipment based on what is selected
            }
            let url = Urls.getEditGymURL(userId: Utils.getUserId()!, gymId: gym!.id!)
            GymClient.editUserGym(url: url, gym: gym!, cb: self.handleEditGym(code:message:))
        }

        //gym id is null so it will be an add
        else {
            if(gymTextField.text == nil || gymTextField.text == "") {
                Utils.getDismissModalWithMessage(title: "Invalid Name", message: "Gym name cannot be blank", cb: nil)
                return
            } else {
                let equipmentString = getEquipmentString()
                GymClient.createUserGym(name: gymTextField.text!, equipment: equipmentString, cb: self.handleCreateGym)
            }
        }
    }
}


