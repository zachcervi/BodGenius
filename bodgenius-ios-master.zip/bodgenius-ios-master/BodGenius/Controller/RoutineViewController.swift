//
//  RoutineViewController.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 12/12/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Alamofire
import Foundation
import UIKit

var daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

class RoutineViewController: BGViewController, UICollectionViewDataSource, UICollectionViewDelegate, UIScrollViewDelegate, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource  {
    
    @IBOutlet weak var suggestionsTableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return suggestedRoutines.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.suggestionsTableView.dequeueReusableCell(withIdentifier: PROFILE_CELL_IDENTIFIER) as! ProfileCell
        cell.configureCell(text: suggestedRoutines[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let height = self.suggestionsTableView.frame.height
        let count: CGFloat = CGFloat(self.suggestionsTableView.numberOfRows(inSection: 0))
        return (height / count)
    }
    
    @IBOutlet weak var secondaryTextLabel: UILabel!
    @IBOutlet weak var closeIcon: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var activeArray = [false, false, false, false, false, false, false]
    var suggestedRoutines = [String]()
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = self.collectionView.frame.height - 10
        let height = self.collectionView.frame.height - 10
        return CGSize(width: width, height: height)
    }
    func setupGestureRecognizers() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        closeIcon.isUserInteractionEnabled = true
        closeIcon.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: {})
    }
    
    override func viewDidLoad() {
        self.setupGestureRecognizers()
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.suggestionsTableView.delegate = self
        self.suggestionsTableView.dataSource = self
        self.suggestionsTableView.isHidden = true
        self.secondaryTextLabel.isHidden = true
    }
    
    var routine: [String]?
    override func viewDidAppear(_ animated: Bool) {
        if(Utils.getUserRoutine() != nil) {
            routine = Utils.getUserRoutine()!
            if(routine!.count != 7) {
                return
            }
            let numCells = self.collectionView.numberOfItems(inSection: 0)
            for i in 0..<numCells {
                activeArray[i] = routine![i] != "off"
            }
            self.collectionView.reloadData()
        }
    }
    
    func handleGetSuggestions(suggestions: [String]?) {
        if(suggestions != nil) {
            self.suggestedRoutines = suggestions!
            self.suggestionsTableView.reloadData()
            self.suggestionsTableView.isHidden = suggestions!.count == 0
            self.secondaryTextLabel.isHidden = suggestions!.count == 0
        } else {
            self.suggestionsTableView.isHidden = true
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        activeArray[indexPath.row] = !activeArray[indexPath.row]
        self.collectionView.reloadData()
        HttpClient.getSuggestedRoutines(activeArray: activeArray, cb: self.handleGetSuggestions)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = "Select This Routine?"
        let message = "(You can change it at any time and as many times as you like by coming back to this page.)"
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { _ in
            HttpClient.chooseRoutine(row: indexPath.row, availability: self.activeArray, cb: self.handleSetRoutine)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func handleSetRoutine(routine: [String]?) {
        if(routine != nil) {
            Utils.setUserRoutine(routine: routine!)
            self.showAlert(title: "Success", message: "Your routine has been set. You can come back and change it up at any time.", callback: {_ in })
        } else {
            self.showAlert(title: "Error", message: "Your routine could not be set at this time, please try agian laterd.", callback: {_ in })
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: ROUTINE_CREATION_CELL_IDENTIFIER, for: indexPath) as! RoutineScheduleCell
        cell.dateLabel.text = daysOfWeek[indexPath.row]
        cell.setActive(active: self.activeArray[indexPath.row])
        if(self.routine != nil && self.routine!.count > indexPath.row) {
            cell.focusLabel.isHidden = false
            cell.focusLabel.text = self.routine![indexPath.row].capitalized
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return daysOfWeek.count
    }
}
