//
//  Workouts.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/8/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation

//Dummy Data
var workoutArray = ["Barbell Incline Press", "Dumbbell Bench Press", "Dumbbell Lateral Raise", "Dumbbell Flye", "Tricep Pushdown", "Bench Dips", "Crunches"]
var woOfWeek = ["Off", "Full-Body", "Off", "Upper Body", "Lower Body", "Off", "Full-Body"]

struct Equipment: Codable {
    var name = EQUIPMENT_NAME_UNKNOWN
}

struct Exercise: Codable {
    var id: Int
    var name: String
    var gif = GIF_NAME_UNKNOWN
    var description: String
    var weights: [Int]
    var reps: [Int]
    var previousWeight: [Int]
    var previousReps: [Int]
    var equipment: [String]
}

var SEPARATOR = "&&&"
var EXERCISE_SEPARATOR = "***"
var EXERCISE_ATTR_SEPARATOR = "###"
var EQUIPMENT_SEPARATOR = "@@@"

struct User: Codable {
    var currentwodate : String
    var goal : String?
    var email : String?
    var gymids : [String]?
    var id : String
    var isactive : String?
    var name : String?
    var password : String?
    var workoutids : [String]?
}

struct Workout: Codable {
    var exercises : [Exercise]
    var date : String
    var id : String
    var focus : [String]?
    var metadata : [String]?
    
    func getHumanReadableType() -> String? {
        if(focus != nil && focus!.count > 0) {
            if(focus![0] == "full") {
                return "Full-Body"
            }
        }
        return nil
    }
    
    mutating func setSet(n: Int, set: Int, weight: Int?, rep: Int?) {
        var e = self.exercises[n]
        if (weight != nil) {
            e.weights[set] = weight!
        }
        if (rep != nil) {
            e.reps[set] = rep!
        }
        self.exercises[n] = e
    }
    
    static func getDateFromDateString(dateString: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.locale = Locale.current
        return dateFormatter.date(from: dateString)
    }
}
