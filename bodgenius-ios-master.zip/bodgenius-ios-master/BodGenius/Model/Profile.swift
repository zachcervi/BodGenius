//
//  Profile.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/7/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation

var profileArray = [VERSION_TITLE, MY_PROGRESS_TITLE, ROUTINE_TITLE, GYMS_TITLE, PRIVACY_TITLE, LOGOUT_TITLE]
