//
//  ExerciseEquipment.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/16/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation

class ExerciseEquipment {
    static var EXERCISE_EQUIPMENT_URLS = [
        "ab-wheel",
        "adjustable-bench",
        "barbell-landmine",
        "cable-machine",
        "chest-press",
        "dumbbell",
        "flat-bench-press",
        "kettlebells",
        "lat-pull-machine",
        "leg-extension-machine",
        "leg-press",
        "medicine-ball",
        "resistance-bands",
        "roman-chair",
        "rowing-machine",
        "squat-rack",
        "stationary-bike"
    ]

   
    
    //"Tredmill", isSelected: True
    public private(set) var  equipmentDictionary: Dictionary<String, Bool>
    
    init(equipment: Dictionary<String, Bool>) {
        self.equipmentDictionary = equipment
    }
    
    
    
    static var EXERCISE_EQUIPMENT_URLS_FORMATTED = [
        "Ab Wheel",
        "Adjustable Bench",
        "Barbell Landmine",
        "Cable Machine",
        "Chest Press",
        "Dumbbell",
        "Flat Bench Press",
        "Kettlebells",
        "Lat Pull Machine",
        "Leg Extension Machine",
        "Leg Press",
        "Medicine Ball",
        "Resistance Bands",
        "Roman Chair",
        "Rowing Machine",
        "Squat Rack",
        "Stationary Bike"
    ]
    
    //TECH DEBT: Need to implement this method to format
    //the exercise equipment names.
//    func formatEquipmentNames() -> [String] {
//        var formatted = [String]()
//        for item in ExerciseEquipment.EXERCISE_EQUIPMENT_URLS {
//            item.replacingOccurrences(of: "-", with: " ")
//            item.capitalized
//            formatted.append(item)
//        }
//        return formatted
//    }
}
