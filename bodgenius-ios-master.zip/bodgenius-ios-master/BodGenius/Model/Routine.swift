//
//  Routine.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 1/16/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation

class Routine: Codable {
    public var id: String;
    public var focuses: [String];
    
    init() {
        id = ""
        focuses = ["off", "off", "off", "off", "off", "off", "off"]
    }
}
