//
//  Gym.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/16/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//
import Foundation
//Dummy Data
//var gymArray = ["Average Joe's", "Global Gym", "24 Hour Fitness"]
class Gym: Codable {
    public  var gymName: String;
    public  var exerciseEquipment: String;
    public private(set) var id: String?
    init(id: String?, gymName:String, exerciseEquipment: String) {
        self.gymName = gymName
        self.exerciseEquipment = exerciseEquipment
        self.id = id
    }
    
}
