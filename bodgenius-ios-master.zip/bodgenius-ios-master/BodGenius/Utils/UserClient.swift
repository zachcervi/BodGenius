//
//  UserClient.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 1/26/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import Alamofire
import Foundation
import SwiftyJSON

enum KeychainError: Error {
    case noPassword
    case unexpectedPasswordData
    case unhandledError(status: OSStatus)
}

class UserClient {
    static func createAccount(cb: @escaping (String?) -> Void, email: String, password: String) -> Void {
        let url = Urls.getAccountCreationUrl()
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .post, parameters: ["email": email, "password": password, "name": "Unset"], encoding: JSONEncoding.default, headers: nil).responseString {
            response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            
            if(response.response?.statusCode == 200) {
                cb(response.result.value!)
            } else if (response.response?.statusCode == 400) {
                cb(ERR_DUPLICATE_EMAIL)
            } else {
                cb(nil)
            }
        }
    }
    
    // Takes in <email> and <password>, returns <userId>.
    // Returns <nil> if email/password don't match
    static func authenticateUser(account: String, password: String, sender: AuthenticationViewController) -> String? {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let url = Urls.getAuthenticateUrl()
        var userId : String? = nil
        Alamofire.request(url, method: .post, parameters: ["userId": account, "password" : password, "clientId": CLIENT_ID],encoding: URLEncoding.httpBody, headers: nil).responseData {
            response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            sender.hideSpinner()
            
            switch response.response?.statusCode {
            case 200:
                let decoder = JSONDecoder()
                let todo: Result<User> = decoder.decodeResponse(from: response)
                if(todo.isSuccess) {
                    Utils.setUser(user: todo.value!)
                    Utils.setUserId(id: todo.value!.id)
                    let server = Urls.getBaseUrl()
                    let credentials = Credentials(username: account, password: password)
                    let encryptedPassword = credentials.password.data(using: String.Encoding.utf8)!
                    let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                                kSecAttrAccount as String: account,
                                                kSecAttrServer as String: server,
                                                kSecValueData as String: encryptedPassword]
                    let status = SecItemAdd(query as CFDictionary, nil)
                    if status != errSecSuccess {
                        if let err = SecCopyErrorMessageString(status, nil) {
                            print("Read failed: \(err)")
                            print("status: \(status)")
                        }
                    } else {
                        print("Keychain Success")
                    }
                    sender.goToLanding()
                } else {
                    sender.present(Utils.getDismissModalWithMessage(title: "Authentication Failed", message: "" , cb: nil), animated: true, completion: nil)
                }
                break
            default:
                userId = nil
                let message = "Please double-check the username you provided (" + String(describing: response.response?.statusCode) + ")"
                sender.present(Utils.getDismissModalWithMessage(title: "Authentication Failed", message: message , cb: nil), animated: true, completion: nil)
                break
            }
        }
        return userId
    }
    
}
