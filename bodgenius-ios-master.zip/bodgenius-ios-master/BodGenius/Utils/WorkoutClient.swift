//
//  WorkoutClient.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 1/29/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class WorkoutClient {
    static func setSetUpdateArray(array: [Int]?) {
        UserDefaults.standard.set(array, forKey: AUTOSCROLL_INDEXES)
    }
    
    static func getSetUpdateArray() -> [Int]? {
        return UserDefaults.standard.array(forKey: AUTOSCROLL_INDEXES) as? [Int]
    }
    
    static func isWorkoutDayForUser() -> Bool {
        let routine = UserDefaults.standard.array(forKey: ROUTINE_KEY) as? [String]
        if (routine != nil) {
            let day = Date().dayNumberOfWeek()!
            if (routine!.count <= day) {
                return false
            }
            return routine![day] != "off" && routine![day] != "Off"
        }
        return false
    }
    
    static func clearCurrentWorkout() {
        UserDefaults.standard.set(nil, forKey: WORKOUT_KEY)
    }
    
    static func currentWorkoutIsForToday() -> Bool {
        if(WorkoutClient.getCurrentWorkout() == nil) {
            return false
        } else {
            return Date().getShortDateString() == WorkoutClient.getDateForLastSavedWorkout()
        }
    }
    
    static func getDateForLastSavedWorkout() -> String? {
        if(WorkoutClient.getCurrentWorkout() == nil ) {
            return nil
        } else {
            return UserDefaults.standard.string(forKey: WORKOUT_DATE_KEY)
        }
    }
    
    static func getCurrentWorkout() -> Workout? {
        let d = UserDefaults.standard
        let wo = d.data(forKey: WORKOUT_KEY)
        if wo != nil {
            do {
                let workout = try JSONDecoder().decode(Workout.self, from: wo!)
                return workout
            } catch {
                return nil
            }
        }
        return nil
    }
    
    static func setCurrentWorkout(workout: Workout) {
        let jsonEncoder = JSONEncoder()
        let jsonDecoder = JSONDecoder()
        do {
            let jsonData = try jsonEncoder.encode(workout)
            let jsonString = String(data: jsonData, encoding: .utf8)
            
            _ = try jsonDecoder.decode(Workout.self, from: Data((jsonString?.utf8)!))
            UserDefaults.standard.set(jsonData, forKey: WORKOUT_KEY)
            UserDefaults.standard.set(Date().getShortDateString(), forKey: WORKOUT_DATE_KEY)
        } catch {
            print(error)
        }
    }
}
