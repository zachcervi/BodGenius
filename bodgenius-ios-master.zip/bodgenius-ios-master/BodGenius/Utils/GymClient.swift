//
//  GymClient.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 1/26/19.
//  Copyright © 2019 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class GymClient {
    static func createUserGym(name: String, equipment: String, cb: @escaping (String?) -> Void) {
        let url = Urls.getCreateGymUrl()
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .post, parameters: ["name": name, "equipment": equipment, "clientId": CLIENT_ID], encoding: JSONEncoding.default, headers: nil).responseString { response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response?.statusCode == 200) {
                cb(response.result.value!)
            } else {
                cb(nil)
            }
        }
    }
    
    static func getUserGym(cb: @escaping (Int, [Gym]?) -> Void){
        let url = Urls.getGymURL(userId: Utils.getUserId()!)
        print(url)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response != nil){
                guard let data = response.data else {return}
                do {
                    let json = try JSON(data: data)
                    var userGyms = [Gym]()
                    print(userGyms)
                    for item in json["gyms"].arrayValue {
                        
                        let id =  item["id"].stringValue
                        let name = item["name"].stringValue
                        let equipment = item["equipment"].stringValue
                        
                        let newGym = Gym(id: id, gymName: name, exerciseEquipment: equipment)
                        userGyms.append(newGym)
                        
                    }
                    cb(response.response!.statusCode, userGyms)
                }catch {
                    
                }
                
            } else {
                cb(500, nil)
            }
        }
    }
    
    static func deleteUserGym(url: String, gymId: String,  cb: @escaping (Int, String?) -> Void){
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let parameters = ["gymId":gymId]
        Alamofire.request(url, method: .delete, parameters: parameters, encoding: JSONEncoding.default, headers: nil).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response?.statusCode == 200){
                cb(200, "SUCCESS")
            }else {
                cb(response.response!.statusCode, response.result.description)
            }
        }
    }
    
    static func editUserGym(url: String, gym: Gym, cb: @escaping (Int, String?)-> Void){
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let gymName = gym.gymName
        let exerciseEquipment = gym.exerciseEquipment
        let parameters = ["name":gymName, "equipment":exerciseEquipment]
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: nil).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response?.statusCode == 200){
                
            }else{
                cb(response.response!.statusCode, response.result.description)
            }
        }
    }
    
    static func setCurrentUserGym(gymId: String?) {
        UserDefaults.standard.set(gymId, forKey: CURRENT_GYM_KEY)
    }
    
    static func getCurrentUserGym() -> String? {
        return UserDefaults.standard.string(forKey: CURRENT_GYM_KEY)
    }
}
