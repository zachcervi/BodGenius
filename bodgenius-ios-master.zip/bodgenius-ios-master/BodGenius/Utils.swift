//
//  Utils.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 9/16/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

struct Credentials {
    var username: String
    var password: String
}

class Utils {
    static func getCachedUserGyms() -> [Gym]? {
        return UserDefaults.standard.array(forKey: USER_GYM_KEY) as? [Gym]
    }
    static func cacheUserGyms(gyms: [Gym]) {
        //UserDefaults.standard.set(gyms, forKey: USER_GYM_KEY)
    }
    static func getStoredExerciseNames() -> [String]? {
        return UserDefaults.standard.array(forKey: STORED_EXERCISE_NAMES) as? [String]
    }
    static func getIdForExerciseName(name: String) -> String? {
        if(UserDefaults.standard.array(forKey: STORED_EXERCISE_NAMES) == nil ||
            UserDefaults.standard.array(forKey: STORED_EXERCISE_IDS) == nil) {
            return nil
        }
        let names = UserDefaults.standard.array(forKey: STORED_EXERCISE_NAMES) as! [String]
        let ids = UserDefaults.standard.array(forKey: STORED_EXERCISE_IDS) as! [String]
        if(names.count != ids.count) {return nil}
        if( names.firstIndex(of: name) != nil) {
            return ids[names.firstIndex(of: name)!]
        }
        return nil
    }
    static func getStoredExerciseNameAndIds() -> [String : String]? {
        let storedNames = UserDefaults.standard.array(forKey: STORED_EXERCISE_NAMES) as? [String]
        let storedIds = UserDefaults.standard.array(forKey: STORED_EXERCISE_IDS) as? [String]
        if(storedNames == nil || storedIds == nil || storedNames?.count != storedIds?.count) {
            return nil
        }
        let names = storedNames!
        let ids = storedNames!
        
        var map = [String : String]()
        for (n, name) in names.enumerated() {
            map[name] = ids[n]
        }
        return map
    }
    
    static func storeExerciseNameAndIds(ids: [String], names: [String]) {
        if(ids.count == 0 || names.count == 0 || (ids.count != names.count)) {
            return
        }
        UserDefaults.standard.set(ids, forKey: STORED_EXERCISE_IDS)
        UserDefaults.standard.set(names, forKey: STORED_EXERCISE_NAMES)
    }
    
    static func setSetUpdateArray(array: [Int]?) {
        UserDefaults.standard.set(array, forKey: AUTOSCROLL_INDEXES)
    }
    
    static func getSetUpdateArray() -> [Int]? {
        return UserDefaults.standard.array(forKey: AUTOSCROLL_INDEXES) as? [Int]
    }
    
    static func isWorkoutDayForUser() -> Bool {
        let routine = UserDefaults.standard.array(forKey: ROUTINE_KEY) as? [String]
        if (routine != nil) {
            let day = Date().dayNumberOfWeek()!
            if (routine!.count >= day) {
                return false
            }
            return routine![day] != "off" && routine![day] != "Off"
        }
        return false
    }

    static func getUserRoutine() -> [String]? {
        return UserDefaults.standard.array(forKey: ROUTINE_KEY) as? [String]
    }

    static func setUserRoutine(routine: [String]) {
        UserDefaults.standard.set(routine, forKey: ROUTINE_KEY)
    }
    
    //1 = local, 2 = staging, 3 = prod
    static func getUserEnv() -> Int {
        if UserDefaults.standard.integer(forKey: ENVIRONMENT_KEY) != 0 {
            return UserDefaults.standard.integer(forKey: ENVIRONMENT_KEY)
        } else {
            return 3
        }
    }
    
    static func setUserEnv(env: Int) {
        UserDefaults.standard.set(env, forKey: ENVIRONMENT_KEY)
    }
    
    static func getDismissModalWithMessage(title: String, message: String, cb: ((UIAlertAction) -> Void)?) -> UIAlertController {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: cb))
        return alert
    }
    
    static func isUserLoggedIn() throws -> Bool {
        if (UserDefaults.standard.string(forKey: USER_ID_KEY) != nil) {
            return true
        }
        
        let server = Urls.getBaseUrl()
        let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                    kSecAttrServer as String: server,
                                    kSecMatchLimit as String: kSecMatchLimitOne,
                                    kSecReturnAttributes as String: true,
                                    kSecReturnData as String: true]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status != errSecItemNotFound else { throw KeychainError.noPassword }
        guard status == errSecSuccess else { throw KeychainError.unhandledError(status: status) }
        guard let existingItem = item as? [String : Any],
            let passwordData = existingItem[kSecValueData as String] as? Data,
            let _ = String(data: passwordData, encoding: String.Encoding.utf8)
            else {
                return false
        }
        return true
    }
    
    static func getUserId() -> String? {
        if(UserDefaults.standard.string(forKey: USER_ID_KEY) != nil) {
            return UserDefaults.standard.string(forKey: USER_ID_KEY)
        } else {
            if Utils.getUser() != nil {
                return Utils.getUser()?.id
            } else {
                return nil
            }
        }
    }
    
    static func setUserId(id: String?) {
        UserDefaults.standard.set(id, forKey: USER_ID_KEY)
    }
    
    static func setUser(user: User) {
        let jsonEncoder = JSONEncoder()
        let jsonDecoder = JSONDecoder()
        do {
            let jsonData = try jsonEncoder.encode(user)
            let jsonString = String(data: jsonData, encoding: .utf8)
            
            _ = try jsonDecoder.decode(User.self, from: Data((jsonString?.utf8)!))
            UserDefaults.standard.set(jsonData, forKey: USER_KEY)
        } catch {
            print(error)
        }
    }
    
    static func clearUser() {
        UserDefaults.standard.set(nil, forKey: USER_KEY)
    }
    
    static func getUser() -> User? {
        let d = UserDefaults.standard
        let wo = d.data(forKey: USER_KEY)
        if wo != nil {
            do {
                let workout = try JSONDecoder().decode(User.self, from: wo!)
                return workout
            } catch {
                return nil
            }
        }
        return nil
    }
    
    static func debugModeOn() -> Bool {
        return UserDefaults.standard.bool(forKey: DEBUG_MODE_KEY) || false
    }
    
    static func toggleDebugMode() {
        let d = UserDefaults.standard
        let current =  d.bool(forKey: DEBUG_MODE_KEY) || false
        d.set(!current, forKey: DEBUG_MODE_KEY)
    }
    
    static func setPrimaryUserGoal(goal: String?) {
        UserDefaults.standard.set(goal, forKey: PRIMARY_GOAL_KEY)
    }
    
    static func getPrimaryGoalOrNull() -> String? {
        return UserDefaults.standard.string(forKey: PRIMARY_GOAL_KEY)
    }
    
    static func setSecondaryUserGoal(goal: String?) {
        UserDefaults.standard.set(goal, forKey: SECONDARY_GOAL_KEY)
    }
    
    static func getSecondaryGoalOrNull() -> String? {
        return UserDefaults.standard.string(forKey: SECONDARY_GOAL_KEY)
    }
    
    static func getGoalStringOrNull() -> String? {
        if Utils.getPrimaryGoalOrNull() != nil {
            var goalString = Utils.getPrimaryGoalOrNull()!
            if Goals.getSecondaryGoals(primaryGoal: goalString) != nil {
                //goalString = goalString + " (" + Utils.getSecondaryGoalOrNull()! + ")"
            }
            return goalString
        } else {
            return nil
        }
    }
}

class Goals {
    static var LOSE_FAT = "Lose Fat"
    static var BUILD_MUSCLE = "Build Muscle"
    static var TONE_BODY = "Tone Parts Of My Body"
    static var INCREASE_MAX = "Increase 1-Rep Max"
    static var primaryGoals = [
        Goals.LOSE_FAT,
        Goals.BUILD_MUSCLE,
        Goals.TONE_BODY,
        Goals.INCREASE_MAX
    ]
    
    static func getSecondaryGoals(primaryGoal: String) -> [String]? {
        switch primaryGoal {
        case Goals.TONE_BODY:
            return [
                "Arms",
                "Shoulders",
                "Back",
                "Glutes",
                "Thighs",
                "Chest",
                "Upper Back",
                "Lower Back",
                "Stomach"]
        case Goals.INCREASE_MAX:
            return ["Bench Press",
                    "Incline Press",
                    "Back Squat",
                    "Military Press",
                    "Deadlift"]
        default:
            return nil
        }
    }
}

class HttpClient {
    static func sendBadWorkoutNotification(workoutData: String) -> Void {
        let url = Urls.getBadWorkoutUrl()
        Alamofire.request(url, method: .post, parameters: ["workout": workoutData], encoding: JSONEncoding.default, headers: nil)
    }
    
    
    static func executeGetRequest(url: String, parameters: [String: Any]?, cb: @escaping (DataResponse<String>) -> Void) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: parameters, encoding: JSONEncoding.default, headers: nil).responseString(completionHandler: HttpClient.getWrappedCallback(cb: cb))
    }
    
    static func executePostRequest(url: String, parameters: [String: Any]?, cb: @escaping (DataResponse<String>) -> Void) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: nil).responseString(completionHandler: HttpClient.getWrappedCallback(cb: cb))
    }
    
    static func getWrappedCallback(cb: @escaping (DataResponse<String>) -> Void) -> ((DataResponse<String>) -> Void) {
        return {response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            cb(response)
        }
    }
    
    static func chooseRoutine(row: Int, availability: [Bool], cb: @escaping([String]?) -> Void) {
        let url = Urls.getChooseRoutineUrl(userId: Utils.getUserId()!)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .post, parameters: ["clientId" : CLIENT_ID, "availability": availability, "index": row], encoding: JSONEncoding.default, headers: nil).responseString(completionHandler: {response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.result.isSuccess) {
                guard let data = response.data else {return}
                do {
                    let json = try JSON(data: data)
                    var routine = [String]()
                    for item in json["routine"].arrayValue {
                        routine.append(item.stringValue)
                    }
                    cb(routine)
                } catch {
                    print(error)
                    cb(nil)
                }
            } else {
                cb(nil)
            }
            
        })
    }
    
    static func getSuggestedRoutines(activeArray: [Bool], cb: @escaping([String]?) -> Void) {
        let url = Urls.getSuggestedRoutineUrl()
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .post, parameters: ["clientId" : CLIENT_ID, "availability": activeArray], encoding: JSONEncoding.default, headers: nil).responseString(completionHandler: { response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.result.isSuccess) {
                guard let data = response.data else {return}
                do {
                    let json = try JSON(data: data)
                    var suggestions = [String]()
                    for item in json["suggestions"].arrayValue {
                        suggestions.append(item.stringValue)
                    }
                    cb(suggestions)
                } catch {
                    cb(nil)
                }
            } else {
                cb(nil)
            }
        })
    }
    
    static func getAllExercises(cb: @escaping([String], [String]) -> Void) {
        let url = Urls.getAllExerciseUrl()
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseString {
            response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response?.statusCode == 200) {
                guard let data = response.data else {return}
                do {
                    let json = try JSON(data: data)
                    var exerciseNames = [String]()
                    var exerciseIds = [String]()
                    for item in json["exercises"].arrayValue {
                        exerciseNames.append(item["name"].stringValue)
                        exerciseIds.append(item["id"].stringValue)
                    }
                    cb(exerciseIds, exerciseNames)
                } catch {
                    cb([String](), [String]())
                }
            } else {
                cb([String](), [String]())
            }
        }
        

    }
    
    static func getExerciseProgress(exerciseId: Int, cb: @escaping([String]?) -> Void) {
        let url = Urls.getExerciseProgressUrl(userId: Utils.getUserId()!, exerciseId: exerciseId)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseString { response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response?.statusCode == 200) {
                guard let data = response.data else {return}
                do {
                    let json = try JSON(data: data)
                    var progress = [String]()
                    for item in json["progress"].arrayValue {
                        let date = item["date"].stringValue
                        let weight = item["weight"].intValue
                        progress.append(date + ": " + String(weight))
                    }
                    print(progress)
                    cb(progress)
                } catch {
                    cb(nil)
                }
            } else {
                cb(nil)
            }
        }
    }

    
    
    static func persistGoal(primary: String, secondary: String?, cb: @escaping (Int, String, String?) -> Void) {
        let url = Urls.getUserGoalUrl(userId: Utils.getUserId()!)
        var goal = primary
        
        if secondary != nil {
            goal = goal + " (" + secondary! + ")"
        }
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .post, parameters: ["goal": goal, "clientId": CLIENT_ID],encoding: JSONEncoding.default, headers: nil).responseString {
            response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response != nil) {
                cb(response.response!.statusCode, primary, secondary)
            } else {
                cb(500, primary, secondary)
            }
        }
    }
    
    static func getUserGoal(cb: @escaping (Int, String?) -> Void) {
        var url = Urls.getUserGoalUrl(userId: Utils.getUserId()!)
        url = url + "?clientId=" + CLIENT_ID
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseString {
            response in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response != nil) {
                cb(response.response!.statusCode, response.result.value)
            } else {
                cb(500, nil)
            }
        }
    }
    
    static func getUserRoutine(cb: @escaping (Int, Routine?) -> Void) {
        let url = Urls.getRoutineUrl(userId: Utils.getUserId()!)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseString { (response) in
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
            if(response.response != nil) {
                guard let data = response.data else {return}
                do {
                    let json = try JSON(data: data)
                    let routine = Routine.init()
                    routine.id = json["id"].stringValue
                    var newFocuses = [String]()
                    for item in json["focuses"].arrayValue {
                        newFocuses.append(item.stringValue)
                    }
                    routine.focuses = newFocuses
                    cb(response.response!.statusCode, routine)
                } catch {
                    cb(response.response!.statusCode, nil)
                }
            } else {
                cb(500, nil)
            }
        }
    }
}

extension JSONDecoder {
    func decodeResponse<T: Decodable>(from response: DataResponse<Data>) -> Result<T> {
        guard response.error == nil else {
            print(response.error!)
            return .failure(response.error!)
        }
        
        guard let responseData = response.data else {
            print("didn't get any data from API")
            return .failure(response.error!)
        }
        
        do {
            let item = try decode(T.self, from: responseData)
            return .success(item)
        } catch {
            print("error trying to decode response")
            print(error)
            return .failure(error)
        }
    }
}

