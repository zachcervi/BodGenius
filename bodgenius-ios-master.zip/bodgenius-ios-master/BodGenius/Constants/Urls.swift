//
//  Urls.swift
//  BodGenius
//
//  Created by Kevin Joseph Trizna Jr on 11/6/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation

var PROD_URL = "https://bodgenius-platform.herokuapp.com"
var STAGING_URL = "https://bodgenius-platform-staging.herokuapp.com"
var TEST_URL = "http://localhost:5000"


class Urls {
    static func getBadWorkoutUrl() -> String {
        return Urls.getBaseUrl() + "/badWorkout"
    } 

    static func getChooseRoutineUrl(userId: String) -> String {
        return Urls.getBaseUrl() + "/user/" + userId + "/routine"
    }
    
    static func getSuggestedRoutineUrl() -> String {
        return Urls.getBaseUrl() + "/routine/suggest"
        
    }
    static func getAllExerciseUrl() -> String {
        return Urls.getBaseUrl() + "/exercise?clientId=" + CLIENT_ID + "&forMobileClient=true"
    }

    static func getExerciseProgressUrl(userId: String, exerciseId: Int) -> String {
        let route = Urls.getBaseUrl() + "/user/" + userId + "/progress/" + String(exerciseId)
        let specifics = "?clientId=" + CLIENT_ID
        return route + specifics
    }
    
    static func getRoutineUrl(userId: String) -> String {
        return Urls.getBaseUrl() + "/user/" + userId + "/routine?clientId=" + CLIENT_ID
    }
    static func getAccountCreationUrl() -> String {
        return Urls.getBaseUrl() + "/user/new" + "?clientId=" + CLIENT_ID
    }
    
    static func getCreateGymUrl() -> String {
        return Urls.getBaseUrl() + "/user/" + Utils.getUserId()! + "/gym"
    }

    static func getBaseUrl() -> String {
        switch (Utils.getUserEnv()) {
        case 1:
            return TEST_URL
        case 2:
            return STAGING_URL
        case 3:
            return PROD_URL
        default:
            return PROD_URL
        }
    }
    static func getUserGoalUrl(userId: String) -> String {
        return Urls.getBaseUrl() + "/user/" + userId + "/goal"
    }
    
    static func getCurrentWorkoutUrl(userId: String) -> String {
        let url = Urls.getBaseUrl() + "/user/" + userId + "/workout/current" + "?clientId=" + CLIENT_ID
        if(GymClient.getCurrentUserGym() != nil) {
            return url + "&gymId=" + GymClient.getCurrentUserGym()!
        } else {
            return url
        }
    }
    
    static func getAuthenticateUrl() -> String {
        print(Urls.getBaseUrl() + "/user/auth")
        return Urls.getBaseUrl() + "/user/auth"
    }
    
    static func getWorkoutUrl(userId: String, workoutId: String) -> String {
        return Urls.getBaseUrl() + "/user/" + userId + "/workout/" + workoutId
    }
    
    static func getGymURL(userId: String) -> String{
        print(Urls.getBaseUrl() + "/user/" + userId + "/gym?" + "clientId=" + CLIENT_ID)
        return Urls.getBaseUrl() + "/user/\(userId)/gym?clientId=\(CLIENT_ID)"
        
    }
    static func getEditGymURL(userId: String, gymId: String)-> String {
        print(Urls.getBaseUrl() + "/user/\(userId)/gym/\(gymId)?clientId=\(CLIENT_ID)")
        return Urls.getBaseUrl() + "/user/\(userId)/gym/\(gymId)?clientId=\(CLIENT_ID)"
    }
}
