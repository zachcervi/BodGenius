//
//  Constants.swift
//  BodGenius
//
//  Created by Zach Cervi on 10/21/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation

//Generic/Master
let BODGENIUS_TITLE = "BodGenius"
let CLIENT_ID = "663e58b8-d4ae-11e8-af68-22143b256222"


//Segues
let TOS_SEGUE = "toTermsOfService"
let TO_CREATE_GYM = "toCreateGym"
let EDIT_GOAL_SEGUE = "editGoal"
let POST_AUTHENTICATION_SEGUE = "postAuthenticationSegue"
let LOGOUT_SEGUE = "logoutSegue"
let STUB_ACCOUNT_SEGUE = "showStubVC"
let ROUTINE_FROM_PROFILE_SEGUE = "editRoutineFromProfile"
let TO_CREATE_GYM_FROM_LANDING = "toCreateGymFromLanding"
let LOGIN_FROM_NEW_ACCOUNT = "loginFromNewAccount"
let PROGRESS_FROM_PROFILE = "progressPageFromProfile"
let GYM_PROFILE = "gymProfile"
let TO_MY_GYMS_FROM_MY_PROFILE = "toMyGymsFromProfile"
let TO_GYM_PROFILE_FROM_USER_PROFILE = "toGymProfileFromUserProfile"
let TO_CREATE_GYM_FROM_MY_GYMS = "toCreateGymsFromMyGyms"


//Utils
let USER_GYM_KEY = "userGymKey"
let STORED_EXERCISE_NAMES = "storedExerciseNames"
let STORED_EXERCISE_IDS = "storedExerciseIds"
let ERR_DUPLICATE_EMAIL = "errDuplicateEmail"
let AUTOSCROLL_INDEXES = "autoscrollIndex"
let ROUTINE_KEY = "routineKey"
let USER_KEY = "userKey"
let PRIMARY_GOAL_KEY = "primaryGoal"
let SECONDARY_GOAL_KEY = "secondaryGoal"
let USER_ID_KEY = "userId"
let WORKOUT_KEY = "workoutDict"
let DEBUG_MODE_KEY = "debugMode"
let ENVIRONMENT_KEY = "userEnvironment"
let CURRENT_GYM_KEY = "currentUserGym"
let WORKOUT_DATE_KEY = "workoutDateKey"


//Profile Page
let VERSION_TITLE = "App Version 0.0.0"
let MY_PROGRESS_TITLE = "My Progress"
let INJURIES_TITLE = "Current Injuries"
let ROUTINE_TITLE = "Routine"
let GYMS_TITLE = "My Gyms"
let NOTIFICATIONS_TITLE = "Notifications"
let PAYMENT_TITLE = "Payment & Billing"
let PRIVACY_TITLE = "Privacy & Data"
let LOGOUT_TITLE = "Logout"


//Exercise Data
let EXERCISE_NAME_UNKNOWN = "UNKNOWN NAME"
let GIF_NAME_UNKNOWN = "UNKNOWN GIF"


//Equipment Data
let EQUIPMENT_NAME_UNKNOWN = "UNKNOWN EQUIPMENT NAME"


//Identifiers
var PROGRESS_SUGGESTION_CELL_IDENTIFIER = "progressSuggestionCell"
var EXERCISE_PROGRESS_CELL_IDENTIFIER = "exerciseProgressCell"
var ROUTINE_CELL_IDENTIFIER = "dayOfWeek"
var PROFILE_CELL_IDENTIFIER = "profileCell"
var EXERCISE_DETAILS_PICKER = "basePicker"
var ROUTINE_CREATION_CELL_IDENTIFIER = "routineDayOfWeek"
var ROUTINE_SUGGESTION_CELL_IDENTIFIER = "routineSuggestionTableCell"

//Text
var TOS_TEXT_INTRO = "Hello and welcome to the BodGenius iOS Open Beta! BodGenius is a new kind of fitness app that aims to automate away as much of the workout process as possible in order to make workouts routines more enjoyable, easier to adhere to, and have a greater impact on your fitness overall."

var TOS_TEXT_GOALS = "The goal of this beta is three-fold: we are looking for feedback on the effectiveness of our core features, any buggy parts of the product, and the UX (design) as a whole. For example, if you have any thoughts on how well our algorithm constructs specific workouts (maybe it's too long, maybe it's not intense enough, etc) we would love to hear about it! If the app crashes every time you try to add a new gym, or something about the way we display exercise progress really irks you, let us know! It is your feedback that is going to make BodGenius something truly special in the fitness community."

var TOS_TEXT_WHAT_TO_DO = "How To Test: Continue reading the rest of the Terms Of Service, particularly the disclaimer, and your account will be created and you'll be able to set your routine for the week. As of now, BodGenius operates on a weekly routine system - you select what days you're available and on those days you'll receive workouts. On your off days, if you please, we'll send over some active recovery routines to help you keep active and recover quicker. Otherwise, play around with whatever you see!"

var TOS_TEXT_DISCLAIMER_1 = "Disclaimer: Consult your physician or other health care professional before starting this or any fitness program to determine if it is right for you. Do not start this fitness program if your physician or health care provider advises against it, and stop immediately if you experience any faintness, dizziness, pain or shortness of breath at any time while exercising."

var TOS_TEXT_DISCLAIMER_2 = "BodGenius is a fitness app that offers workouts that we believe are best-tailored to the specific user. This is not a substitute or replacement for routine professional medical advice and any diagnosis or treatment. Do not allow any information or habits stemming from usage of this app prevent or delay you from seeking medical attention or advice from a professional physician or health care provider at any time. The workouts provided from this app are to be performed solely at your own risk."

var DATA_PRIVACY_1 = "BodGenius does not require, collect, or store any data at this time that is personally identifiable information (name, gender, etc) other than your email. We do not give any of our users' data to third-party companies whether it is their email, their workout schedule, or any other stored data from the platform. User passwords are stored using a salted hash generated from modern-day cryptography algorithms and all communication between the app and the servers use standard HTTPS."
