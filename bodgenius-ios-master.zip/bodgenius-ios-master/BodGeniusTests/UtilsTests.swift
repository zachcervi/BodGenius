//
//  UtilsUnitTests.swift
//  BodGeniusTests
//
//  Created by Kevin Joseph Trizna Jr on 10/15/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import XCTest
@testable import BodGenius

class UtilsTests: XCTestCase {
    
    override func setUp() {
        super.setUp()

        let d = UserDefaults.standard
        d.set(nil, forKey: PRIMARY_GOAL_KEY)
        d.set(nil, forKey: SECONDARY_GOAL_KEY)
        d.set(nil, forKey: "debugMode")
        d.set(nil, forKey: "workoutDict")
        d.set(nil, forKey: "userId")
    }
    
    override func tearDown() {
        super.tearDown()
        
        let d = UserDefaults.standard
        d.set(nil, forKey: PRIMARY_GOAL_KEY)
        d.set(nil, forKey: SECONDARY_GOAL_KEY)
        d.set(nil, forKey: "debugMode")
        d.set(nil, forKey: "workoutDict")
        d.set(nil, forKey: "userId")
    }
    
    func testPrimaryGoalSetAndGet() {
        XCTAssert(Utils.getPrimaryGoalOrNull() == nil)
        Utils.setPrimaryUserGoal(goal: "foobar")
        XCTAssert(UserDefaults.standard.string(forKey: PRIMARY_GOAL_KEY)! == "foobar")
        XCTAssert(Utils.getPrimaryGoalOrNull() == "foobar")
        
        XCTAssert(Utils.getSecondaryGoalOrNull() == nil)
        Utils.setSecondaryUserGoal(goal: "foo")
        XCTAssert(UserDefaults.standard.string(forKey: SECONDARY_GOAL_KEY)! == "foo")
        XCTAssert(Utils.getSecondaryGoalOrNull() == "foo")
    }
    
    func testDebugModeSetAndGet() {
        XCTAssert(!Utils.debugModeOn())
        Utils.toggleDebugMode()
        XCTAssert(UserDefaults.standard.bool(forKey: "debugMode"))
        XCTAssert(Utils.debugModeOn())
        Utils.toggleDebugMode()
        XCTAssert(UserDefaults.standard.bool(forKey: "debugMode") == false)
        XCTAssert(!Utils.debugModeOn())
    }
    
    func testUserIdSetAndGet() {
        XCTAssert(!Utils.isUserLoggedIn())
        XCTAssert(Utils.getUserId() == nil)
        
        let userString = "111"
        Utils.setUserId(id: userString)
        
        XCTAssert(Utils.isUserLoggedIn())
        XCTAssert(Utils.getUserId() == userString)
        XCTAssert(UserDefaults.standard.string(forKey: "userId") == userString)
    }
//    TODO: Re-enable when you have the chance
//    func testCurrentWorkoutSetAndGet() {
//        var workout = Workout()
//        let dateObj = Date()
//        workout.date = dateObj
//
//        var ex1 = Exercise()
//        ex1.name = "name"
//        ex1.gif = "gif"
//        ex1.reps = [10, 10, 10, 10]
//        ex1.weights = [5, 10, 15, 20]
//        ex1.weightRange = [0, 0]
//
//        var ex2 = Exercise()
//        ex2.name = "name2"
//        ex2.gif = "gif2"
//        ex2.reps = [11, 11, 11, 11]
//        ex2.weights = [6, 11, 16, 21]
//        ex2.weightRange = [1, 10]
//
//        workout.exercises = [ex1, ex2]
//        Utils.setCurrentWorkout(workout: workout)
//        let w2 = Utils.getCurrentWorkout()
//        XCTAssert(workout.date == w2!.date)
//        for (n, e) in workout.exercises.enumerated() {
//            XCTAssert(e.name == w2!.exercises[n].name)
//            XCTAssert(e.gif == w2!.exercises[n].gif)
//            XCTAssert(e.reps == w2!.exercises[n].reps)
//            XCTAssert(e.weights == w2!.exercises[n].weights)
//            XCTAssert(e.weightRange == w2!.exercises[n].weightRange)
//        }
//    }
}
