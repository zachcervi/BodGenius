//
//  WorkoutUnitTests.swift
//  BodGeniusTests
//
//  Created by Kevin Joseph Trizna Jr on 10/23/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import XCTest
@testable import BodGenius

class WorkoutUnitTests: XCTestCase {
    var dateString: String!
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        let format = DateFormatter()
        format.dateFormat = "dd-MM-yyy"
        dateString = format.string(from: Date())
        
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testWorkoutToString() {
        let eas = Workout.EXERCISE_ATTR_SEPARATOR
        let expectedString = dateString + Workout.SEPARATOR + "exercise1" + eas + "500" + eas + "10" + eas + "501" + eas + "10" + Workout.EXERCISE_SEPARATOR + "exercise2" + eas + "0" + eas + "100" + eas + "300" + eas + "10000"
        
        var wo = Workout()
        wo.date = Date()
        var exercise1 = Exercise()
        exercise1.name = "exercise1"
        exercise1.reps = [10, 10]
        exercise1.weights = [500, 501]
        
        var exercise2 = Exercise()
        exercise2.name = "exercise2"
        exercise2.reps = [100, 10000]
        exercise2.weights = [0, 300]
        
        wo.exercises = [exercise1, exercise2]
        
        XCTAssert(expectedString == wo.toString())
        
        
    }
    
    func testStringToWorkout() {
        var wo = Workout()
        wo.date = Date()
        var exercise1 = Exercise()
        exercise1.name = "exercise1"
        exercise1.reps = [10, 10]
        exercise1.weights = [500, 501]
        
        var exercise2 = Exercise()
        exercise2.name = "exercise2"
        exercise2.reps = [100, 10000]
        exercise2.weights = [0, 300]
        
        //todo(KT)
    }
    
    //todo(KT)
    func testThrowsForBadString() {
        
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
