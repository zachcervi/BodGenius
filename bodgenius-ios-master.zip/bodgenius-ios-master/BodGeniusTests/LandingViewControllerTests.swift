//
//  LandingViewControllerTests.swift
//  BodGeniusTests
//
//  Created by Kevin Joseph Trizna Jr on 10/13/18.
//  Copyright © 2018 Kevin Joseph Trizna Jr. All rights reserved.
//

import Foundation
import XCTest
@testable import BodGenius

class LandingViewControllerTests: XCTestCase {
    var vc: MockLandingViewController = MockLandingViewController()
    
    override func setUp() {
        super.setUp()
        vc = MockLandingViewController()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    // On viewDidLoad, setupDelegates is called.
    func testViewDidLoadSetsUpDelegatesAndGestureRecognizers() {
        vc.viewDidLoad()
        XCTAssert(vc.setupDelegatesCalled)
        XCTAssert(vc.setupGestureRecognizersCalled)
        XCTAssert(vc.routineCollectionView.delegate!.isEqual(vc))
        XCTAssert(vc.routineCollectionView.dataSource!.isEqual(vc))
        XCTAssert(vc.gymTableView.dataSource!.isEqual(vc))
        XCTAssert(vc.gymTableView.delegate!.isEqual(vc))
    }
    
    func testViewDidLoadGetsWorkout() {
        XCTAssert(!vc.getWorkoutCalled)
        vc.viewDidLoad()
        XCTAssert(vc.getWorkoutCalled)
    }
}

class MockLandingViewController: LandingViewController {
    var setupDelegatesCalled = false
    var setupGestureRecognizersCalled = false
    var getWorkoutCalled = false
    var stubbedDogfoodLabel = UILabel()
    var stubbedDebugControl = UISegmentedControl()
    var stubbedPreviousWorkouts = UITableView()
    var stubbedEditGoalIcon = UIImageView()
    var stubbedRoutineCollectionView: UICollectionView!
    
    
    override func viewDidLoad() {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = UICollectionViewScrollDirection.vertical
        let cv = UICollectionView(frame: CGRect(x: 0, y: 0, width: 0, height: 0), collectionViewLayout: layout)
        self.stubbedRoutineCollectionView = cv
        super.viewDidLoad()
    }
    
    override func enableGymForWorkoutDay() { }
    
    override func getWorkout() {
        super.getWorkout()
        self.getWorkoutCalled = true
    }
    
    override func setupDelegates() {
        super.setupDelegates()
        setupDelegatesCalled = true
    }
    
    override func setupGestureRecognizers() {
        super.setupGestureRecognizers()
        setupGestureRecognizersCalled = true
    }
    
    override var editGoalIcon: UIImageView! {
        get {return stubbedEditGoalIcon}
        set{}
    }
    override var dogfoodLabel: UILabel! {
        get {return stubbedDogfoodLabel}
        set{}
    }
    
    override var debugControl: UISegmentedControl! {
        get {return stubbedDebugControl}
        set{}
    }
    
    override var gymTableView: UITableView! {
        get {return stubbedPreviousWorkouts}
        set{}
    }
    
    override var routineCollectionView: UICollectionView! {
        get {return self.stubbedRoutineCollectionView}
        set{}
    }
}
